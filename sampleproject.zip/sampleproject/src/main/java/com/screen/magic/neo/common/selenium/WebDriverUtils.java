package com.screen.magic.neo.common.selenium;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class WebDriverUtils {

	public WebDriver driver;
	public ThreadLocal<RemoteWebDriver> threadDriver = null;
	static DesiredCapabilities capabilities;
	static ChromeOptions chromeOptions;
	public String runParallel = "false";
	public boolean setCookie = false;
	public String projectName="";
	public String downloadFolderName="";
	public static String browserVersion="No Version found";
	public static String browserName="No Brower Name found";
	
	/*
	 * String driverPath = File.separator+"src"+File.separator+"main"+
	 * File.separator+"resources"+File.separator+"chromedriver.exe";
	 */
	String driverPath = File.separator + "src" + File.separator + "main" + File.separator + "resources"
			+ File.separator;

	public String getRunParellel() {
		return runParallel;
	}

	public void setRunParellel(String runParellel) {
		this.runParallel = runParellel;
	}

	public WebDriver getDriver() {
		if (threadDriver == null) {
			return driver;
		} else {
			return threadDriver.get();
		}
	}

	public void setDriverPath(String BrowserName) {
		switch (BrowserName) {
		case "Opera":
			if (System.getProperty("os.name").toLowerCase().contains("mac")) {
				this.driverPath = driverPath + "operadriver";
			} else {
				this.driverPath = driverPath + "operadriver.exe";
			}
			break;
		case "Firefox":
			if (System.getProperty("os.name").toLowerCase().contains("mac")) {
				this.driverPath = driverPath + "geckodriver";
			} else {
				this.driverPath = driverPath + "geckodriver.exe";
			}
			break;
		case "Chrome":
			if (System.getProperty("os.name").toLowerCase().contains("mac")) {
				this.driverPath = driverPath + "chromedriver";
			} else {
				this.driverPath = driverPath + "chromedriver.exe";
			}
			break;
		case "Edge":
			if (System.getProperty("os.name").toLowerCase().contains("mac")) {
				this.driverPath = driverPath + "msedgedriver";
			} else {
				this.driverPath = driverPath + "msedgedriver.exe";
			}
			break;
		case "IE":
			if (System.getProperty("os.name").toLowerCase().contains("mac")) {
				this.driverPath = driverPath + "IEDriverServer";
			} else {
				this.driverPath = driverPath + "IEDriverServer.exe";
			}
			break;
		}
	}	

	public String getDriverPath() {
		return driverPath;
	}

	public void setDriver(ThreadLocal<RemoteWebDriver> threadDriver) {
		this.threadDriver = threadDriver;
	}

	public void setDriver(WebDriver webdriver) {
		this.driver = webdriver;
	}

	public void initializeHtmlDriver() {
		//setDriver(new HtmlUnitDriver());
	}

	public void initializeDriver(String browserType, String hubURL) throws Exception {
		setParallelFlag(hubURL,browserType);
		if (!runParallel.equalsIgnoreCase("true")) {
			switch (browserType) {
			case "Chrome":
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				setDriver(new ChromeDriver());
				break;
			case "Firefox":
				setDriverPath("Firefox");
				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+ getDriverPath());
				setDriver(new FirefoxDriver());
				break;
			case "IE":
				setDriverPath("IE");
				System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + getDriverPath());
				setDriver(new InternetExplorerDriver());
				break;
			case "Edge":
				setDriverPath("Edge");
				System.setProperty("webdriver.edge.driver", System.getProperty("user.dir")+ getDriverPath());
				setDriver(new EdgeDriver());
				break;
			case "Safari":
				setDriver(new SafariDriver());
				break;
			case "Opera":
				setDriverPath("Opera");
				System.setProperty("webdriver.opera.driver", System.getProperty("user.dir") + getDriverPath());
				setDriver(new OperaDriver());
				break;
			default:
				System.out.println("Initializing Chrome Browser By Default");
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				setDriver(new ChromeDriver());
				break;
			}
		} else {
			DesiredCapabilities capabilities;
			switch (browserType) {
			case "Chrome":
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				capabilities= DesiredCapabilities.chrome();
				setDriver(new RemoteWebDriver(new URL(hubURL), capabilities));
				break;
			case "Firefox":
				setDriverPath("Firefox");
				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+ getDriverPath());
				capabilities = DesiredCapabilities.firefox();
				setDriver(new RemoteWebDriver(new URL(hubURL), capabilities));
				break;
			case "IE":
				setDriverPath("IE");
				System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + getDriverPath());
				capabilities=DesiredCapabilities.internetExplorer();
				setDriver(new RemoteWebDriver(new URL(hubURL), capabilities));
				break;
			case "Safari":
				capabilities = DesiredCapabilities.safari();
				capabilities.setPlatform(Platform.MAC);
				driver=new RemoteWebDriver(new URL(hubURL),capabilities);
				setDriver(driver);
				break;
			case "Opera":
				setDriverPath("Opera");
				System.setProperty("webdriver.opera.driver", System.getProperty("user.dir") + getDriverPath());
				capabilities = DesiredCapabilities.opera();
				setDriver(new RemoteWebDriver(new URL(hubURL), capabilities));
				break;
			case "Edge":
				setDriverPath("Edge");
				System.setProperty("webdriver.edge.driver", System.getProperty("user.dir")+ getDriverPath());
				capabilities = DesiredCapabilities.edge();
				setDriver(new RemoteWebDriver(new URL(hubURL), capabilities));
				break;
			default:
				System.out.println("Initializing Chrome Browser By Default");
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				capabilities = DesiredCapabilities.chrome();
				setDriver(new RemoteWebDriver(new URL(hubURL), capabilities));
				break;
			}
		}
		getBrowserDetais();
	}
	

	public void initializeDriverWithDownloadCapabilities(String browserType, String hubURL) {
		setParallelFlag(hubURL,browserType);		
		if(!runParallel.equalsIgnoreCase("true")) {
			Map<String, Object> prefs = new HashMap<String, Object>();
			DesiredCapabilities capabilities;
			switch(browserType) {
			case "Chrome":
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				prefs.put("plugins.always_open_pdf_externally", true);   // to prevent PDF file to Open in Chrome PDF Viewer
				prefs.put("download.default_directory",  System.getProperty("user.dir")+ File.separator + "downloadFiles");
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", prefs);
				capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				setDriver(new ChromeDriver(capabilities));
				break;
			case "Firefox":
				setDriverPath("Firefox");
				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+ getDriverPath());
				FirefoxProfile profile=new FirefoxProfile();
				FirefoxOptions foptions = new FirefoxOptions();
				profile.setPreference("browser.download.folderList", 2);
				profile.setPreference("browser.download.dir", System.getProperty("user.dir")+File.separator
			               +"downloadFiles");
				profile.setPreference("browser.download.manager.showWhenStarting", false);
				profile.setPreference("browser.helperApps.neverAsk.saveToDisk","text/csv,application/java-archive, application/x-msexcel,"
									+ "application/excel,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/x-excel,"
									+ "application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,"
									+ "application/vnd.microsoft.portable-executable");
				foptions.setProfile(profile);
				setDriver(new FirefoxDriver(foptions));
				break;
			case "IE":
				break;
			case "Edge":
				System.out.println("Edge chromium support would be available in next version of WebDriverUtils");
				break;
			default:
				System.out.println("Initializing Chrome Browser By Default");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				setDriver(new ChromeDriver());
				break;
			}
		}
		else {
			switch(browserType) {
			case "Chrome":
				System.out.println("Chrome remote driver download capability would be available in next version of WebDriverUtils");
			case "Firefox":
				System.out.println("Firefox remote driver download capability would be available in next version of WebDriverUtils");
			case "IE":
				System.out.println("IE remote driver download capability would be available in next version of WebDriverUtils");
			case "Edge":
				System.out.println("Edge chromium remote driver download capability would be available in Selenium4");
			default:
				System.out.println("Initializing Chrome Browser By Default");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				setDriver(new ChromeDriver());
				break;
			}	
		}
		getBrowserDetais();
	}

	
	public <capabilities> void initializeDriverWithDownloadCapabilities(Boolean PDFviewerResults,String type, String hubURL) throws Exception {
		setParallelFlag(hubURL,type);
		if(verifyCompatibility()==false) {
			   throw new Exception("Unable to execute due to automation dashboard incompatibility to maven");
		}
		Map<String, Object> prefs = new HashMap<String, Object>();
		if (runParallel.equals("true")) {
			switch (type) {
			case "Firefox":
				System.setProperty("webdriver.gecko.driver",WebDriverUtils.class.getResource( File.separator +"geckodriver.exe").getFile());
				capabilities = new DesiredCapabilities();
				FirefoxProfile fp = new FirefoxProfile();
				capabilities.setCapability(FirefoxDriver.PROFILE, fp);
				capabilities.setBrowserName(DesiredCapabilities.firefox().getBrowserName());
				threadDriver.set(new RemoteWebDriver(new URL(hubURL), capabilities));
				setDriver(threadDriver);
				break;
			case "Chrome":
				System.setProperty("webdriver.chrome.driver",WebDriverUtils.class.getResource( File.separator +"chromedriver.exe").getFile());
				prefs.put("plugins.always_open_pdf_externally", true);   // to prevent PDF file to Open in Chrome PDF Viewer
				prefs.put("download.default_directory",  System.getProperty("user.dir")+ File.separator + "downloadFiles");
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", prefs);
				capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				threadDriver.set(new RemoteWebDriver(new URL(hubURL), capabilities));
				setDriver(threadDriver);
				break;
			case "Edge":
				setDriverPath("Edge");
				System.setProperty("webdriver.edge.driver", System.getProperty("user.dir")+ getDriverPath());
				DesiredCapabilities edgeCapabilities = DesiredCapabilities.edge();
				edgeCapabilities.setCapability("InPrivate", true);
				setDriver(new RemoteWebDriver(new URL(hubURL), edgeCapabilities));
				break;				
			case "Safari":
				capabilities = DesiredCapabilities.safari();
				capabilities.setPlatform(Platform.MAC);
				driver=new RemoteWebDriver(new URL(hubURL),capabilities);
				setDriver(driver);
				break;
			}
		} else if (runParallel.equals("false")) {
			switch (type) {
			case "Edge":
				setDriverPath("Edge");
				System.setProperty("webdriver.edge.driver", System.getProperty("user.dir")+ getDriverPath());
				EdgeOptions eoptions= new EdgeOptions();
				setDriver(new EdgeDriver(eoptions));
				break;
			case "Opera":
				setDriverPath("Opera");
				System.setProperty("webdriver.opera.driver", System.getProperty("user.dir") + getDriverPath());
				if (PDFviewerResults==false) {prefs.put("plugins.always_open_pdf_externally", false);}
				else {prefs.put("plugins.always_open_pdf_externally", true);}
				prefs.put("download.default_directory",  System.getProperty("user.dir")+ File.separator + "downloadFiles");
				ChromeOptions option = new ChromeOptions();
				option.setExperimentalOption("prefs", prefs);
	            option.setBinary("C:\\Program Files\\Opera\\launcher.exe");
				DesiredCapabilities cap=DesiredCapabilities.opera();
				cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	            cap.setCapability(ChromeOptions.CAPABILITY, option);
				setDriver(new OperaDriver(cap));
				break;
			case "Firefox":
				System.setProperty("webdriver.gecko.driver", WebDriverUtils.class.getResource( File.separator +"geckodriver.exe").getFile());
				setDriver(new FirefoxDriver());
				break;
			case "Chrome":
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				if (PDFviewerResults==false) {prefs.put("plugins.always_open_pdf_externally", false);}
				else {prefs.put("plugins.always_open_pdf_externally", true);}
				prefs.put("download.default_directory",  System.getProperty("user.dir")+ File.separator + "downloadFiles");
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", prefs);
				capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				setDriver(new ChromeDriver(capabilities));
				break;
			case "Safari":
				setDriver(new SafariDriver());
				break;
			}
		}
		getBrowserDetais();
	}
	
	public void initializeDriverWithRedirectCapabilities(String browserType, String hubURL) throws Exception {
		setParallelFlag(hubURL,browserType);
		if (!runParallel.equalsIgnoreCase("true")) {
			switch (browserType) {
			case "Chrome":
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--disable-notifications");
				chromeOptions.addArguments("--disable-web-security");
				setDriver(new ChromeDriver(chromeOptions));
				break;
			default:
				System.out.println("Initializing Chrome Browser By Default");
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--disable-notifications");
				chromeOptions.addArguments("--disable-web-security");
				setDriver(new ChromeDriver(chromeOptions));
				break;
			}
		} else {
			DesiredCapabilities capabilities;
			switch (browserType) {
			case "Chrome":
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--disable-notifications");
				chromeOptions.addArguments("--disable-web-security");
				capabilities= DesiredCapabilities.chrome();
				capabilities.setCapability("chromeOptions", chromeOptions);
				setDriver(new RemoteWebDriver(new URL(hubURL), capabilities));
				break;
			default:
				System.out.println("Initializing Chrome Browser By Default");
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--disable-notifications");
				chromeOptions.addArguments("--disable-web-security");
				capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability("chromeOptions", chromeOptions);
				setDriver(new RemoteWebDriver(new URL(hubURL), capabilities));
				break;
			}
		}
		getBrowserDetais();
	}
	
	public Boolean verifyCompatibility(){
		try {
			if(System.getProperty("rp.endpoint").contains("http://52.250.110.62:8080")){
				return false;
			}
			else {
				return true;
			}
		}
		catch(NullPointerException e) {
			   return true;
		}
	} 
  	
	/*
	 * public static void main(String[] args) throws Exception { WebDriverUtils
	 * webDriverUtils = new WebDriverUtils();
	 * webDriverUtils.initializeDriver("Edge", "");
	 * webDriverUtils.getDriver().get("http://google.com");
	 * 
	 * }
	 */
	
	public List<Integer> verifyJar() {
		List<Integer> strs=new ArrayList<Integer>();
		strs.add(5);
		strs.add(7);
		strs.add(10);
		strs.add(4);
		strs.add(5);
		return strs.stream().filter(c->c<10).distinct().collect(Collectors.toList());
	}
 	/*
 	 * It will download the files under your project folder , you can set the name of download folder using setDownloadDirectory in your script
 	 */
	public void initializeDriverWithDownloadAtDesiredLocation(String browserType, String hubURL) {
		setParallelFlag(hubURL,browserType);
		if(!runParallel.equalsIgnoreCase("true")) {
			Map<String, Object> prefs = new HashMap<String, Object>();
			DesiredCapabilities capabilities;
			switch(browserType) {
			case "Chrome":	
				setDriverPath("Chrome");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				prefs.put("plugins.always_open_pdf_externally", true);   // to prevent PDF file to Open in Chrome PDF Viewer
				//add key and value to map as follow to switch off browser notification
				//Pass the argument 1 to allow and 2 to block
				prefs.put("profile.default_content_setting_values.notifications", 2);
				prefs.put("download.default_directory",  System.getProperty("user.dir") + File.separator + "src"+ File.separator + "main"+ File.separator +"resources" + File.separator + this.projectName +  File.separator + this.downloadFolderName);
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", prefs);
				setDriver(new ChromeDriver(options));
				break;
			case "Firefox":
				setDriverPath("Firefox");
				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+ getDriverPath());
				FirefoxProfile profile=new FirefoxProfile();
				FirefoxOptions foptions = new FirefoxOptions();
				profile.setPreference("browser.download.folderList", 2);
				profile.setPreference("browser.download.dir", System.getProperty("user.dir")+File.separator
			               +"downloadFiles");
				profile.setPreference("browser.download.manager.showWhenStarting", false);
				profile.setPreference("browser.helperApps.neverAsk.saveToDisk","text/csv,application/java-archive, application/x-msexcel,"
									+ "application/excel,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/x-excel,"
									+ "application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,"
									+ "application/vnd.microsoft.portable-executable");
				foptions.setProfile(profile);
				setDriver(new FirefoxDriver(foptions));
				break;
			case "IE":
				break;
			case "Edge":
				System.out.println("It will download files at download folder. Use findAndMoveFileFromDownloadFolder to move the file at desired location");
				setDriverPath("Edge");
				System.setProperty("webdriver.edge.driver", System.getProperty("user.dir")+ getDriverPath());
				setDriver(new EdgeDriver());
				break;
			default:
				System.out.println("Initializing Chrome Browser By Default");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				setDriver(new ChromeDriver());
				break;
			}
		}
		else {
			switch(browserType) {
			case "Chrome":
				System.out.println("Chrome remote driver download capability would be available in next version of WebDriverUtils");
			case "Firefox":
				System.out.println("Firefox remote driver download capability would be available in next version of WebDriverUtils");
			case "IE":
				System.out.println("IE remote driver download capability would be available in next version of WebDriverUtils");
			case "Edge":
				System.out.println("Edge chromium remote driver download capability would be available in Selenium4");
			default:
				System.out.println("Initializing Chrome Browser By Default");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ getDriverPath());
				setDriver(new ChromeDriver());
				break;
			}	
		}
	}
	/*
	 * Pass the name of the download folder
	 * 
	 */
	public void setDownloadDirectory(String downloadFolder)  {
		StackTraceElement packagePath = null;
	    StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
	    for (int i = 0; i < stacktrace.length; i++) {
	    	if(stacktrace[i].toString().contains("com.screenmagic") )
	    	 {
	    		packagePath = stacktrace[i];
	    		break;
	    	}
		}

	    String [] arrayPackageName = packagePath.toString().split("\\.");
	    String packageName ="";
	    if(packagePath.toString().contains("com.screenmagic")) {
	    	packageName = arrayPackageName[3];
	    } else {
	    	packageName = arrayPackageName[2];
	    }
		this.projectName = packageName;
	    this.downloadFolderName=downloadFolder;
	}
	/*
	 * Specifically designed for Edge browser as it will download the file in download folder. 
	 */
	public void findAndMoveFileFromDownloadFolder(String fileName, String destination) throws IOException {
		 String home = System.getProperty("user.home");
		 Path path = Files.move(Paths.get(home+ File.separator + "Downloads" + File.separator +  fileName),  
		 Paths.get(destination + File.separator + fileName)); 
  
	     if(path != null) 
	     { 
	            System.out.println("File moved successfully"); 
	     } 
		 else
		 { 
			    System.out.println("Failed to move the file"); 
	     } 
	 }
	public void setParallelFlag(String hubURL,String browser)  {
        if (hubURL != null && hubURL.length() > 0 && browser.equalsIgnoreCase("safari"))
            setRunParellel("true");
    }
	
	public void getBrowserDetais()
	{
		Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
	    String browserName = cap.getBrowserName().toLowerCase();
	    String version = cap.getVersion().toString();
	    this.browserName=browserName;
	    this.browserVersion=version;
	}
}