package com.screen.magic.neo.common.apis;

import java.util.Map;

public class CustomSettingsPOJO {

    private String requestType;
    private Map<Object,Object> data;


}
