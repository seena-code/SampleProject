package com.screen.magic.neo.common.customException;

import com.screen.magic.StepDefinition;
import com.screen.magic.neo.common.helpers.JavaHelpers;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@SuppressWarnings("serial")
public class CustomException extends RuntimeException {

	private String message = null;
	public WebDriver driver;

	public CustomException() {
		super();
	}

	 
	public CustomException(Exception e) throws Exception {

		String strExceptionClass = e.getClass().getCanonicalName().substring(0,
				e.getClass().getCanonicalName().lastIndexOf("."));

		String exceptionTrace=null;
		ExceptionFormatter exceptionFormatter = new ExceptionFormatter();
		
		for(int i=0; i<e.getStackTrace().length; i++) {
			if(e.getStackTrace()[i].toString().contains("com.screenmagic")) 
			 {
				exceptionTrace=e.getStackTrace()[i].getClassName()+"."+
					e.getStackTrace()[i].getMethodName()+":"+e.getStackTrace()[i].getLineNumber();
				
				break;
			}
			}
		
		
		switch (strExceptionClass) {
		
		case "java.lang":
			
			throw new Exception("Exception:" +e.getMessage() +"<br>Issue Type: Script Issue <br>ExceptionTrace:"+exceptionTrace +"<br>Detailed Trace:<br>"+ exceptionFormatter.toHtml(exceptionFormatter.format(e)));

		case "java.io":
			throw new Exception("Exception:" +e.getMessage() +"<br>Issue Type:Script Issue <br>ExceptionTrace:"  +exceptionTrace +"<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

		case "selenium.common.exceptions":
			throw new Exception("Exception:" +e.getMessage() +"<br>Issue Type:Application Issue <br>ExceptionTrace:" +exceptionTrace +"<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

		case "org.openqa.selenium":
			throw new Exception("Exception:" +e.getMessage() +"<br>Issue Type:Application Issue <br>ExceptionTrace:" +exceptionTrace +"<br>Detailed Trace:<br>"  + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

		case "com.screenmagic.customException":
			throw new Exception("Exception:" +e.getMessage() +"<br>Issue Type:Application Issue <br>ExceptionTrace:" +exceptionTrace +"<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

		default:
			throw new Exception("Exception:" +e.getMessage() +"<br>Issue Type:Error Occurred <br>ExceptionTrace:"  +exceptionTrace +"<br>Detailed Trace:<br>"+ exceptionFormatter.toHtml(exceptionFormatter.format(e)));

		}
	}

	public CustomException(Exception e, WebDriver driver) throws Exception {
		try {
			this.driver = driver;

			String strExceptionClass = e.getClass().getCanonicalName().substring(0,
					e.getClass().getCanonicalName().lastIndexOf("."));

			ExceptionFormatter exceptionFormatter = new ExceptionFormatter();
			String exceptionTrace = null;
			if (driver != null) {

				for (int i = 0; i < e.getStackTrace().length; i++) {
					if (e.getStackTrace()[i].toString().contains("com.screenmagic")) {

						exceptionTrace = e.getStackTrace()[i].getClassName() + "."
								+ e.getStackTrace()[i].getMethodName()
								+ ":" + e.getStackTrace()[i].getLineNumber();
						break;
					}


				}

				switch (strExceptionClass) {

					case "java.lang":
						throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Script Issue <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

					case "java.io":
						throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Script Issue <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

					case "selenium.common.exceptions":

						String fileName1 = "screenshot" + JavaHelpers.generateRandomNumber() + ".png";
						try {
							File screenshots1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
							FileUtils.copyFile(screenshots1, new File(fileName1));
							File file = new File(screenshots1.getAbsolutePath());

						} finally {
							//FileUtils.forceDelete(file);
							throw new Exception(
									"Exception:" + e.getMessage() + "<br>Issue Type:Application Issue <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));
						}
					case "org.openqa.selenium":
						String fileName2 = "screenshot" + JavaHelpers.generateRandomNumber() + ".png";
						try {
							File screenshots2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
							FileUtils.copyFile(screenshots2, new File(fileName2));
							File file1 = new File(screenshots2.getAbsolutePath());

							//FileUtils.forceDelete(file1);
						} finally {
							throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Application Issue <br>ExceptionTrace:" + exceptionTrace + "<br>"
									+ "Detailed Trace: <br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));
						}
					case "com.screenmagic.customException":
						throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Application Issue <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

					default:
						String fileName3 = "screenshot" + JavaHelpers.generateRandomNumber() + ".png";
						try {
							File screenshots3 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
							FileUtils.copyFile(screenshots3, new File(fileName3));
							File file2 = new File(screenshots3.getAbsolutePath());

						} finally {
							//FileUtils.forceDelete(file2);
							throw new Exception(
									"Exception:" + e.getMessage() + "<br>Issue Type:Application Issue <br>ExceptionTrace:" + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));
						}
				}
			} else {
				throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Script Issue <br> WebDriver is null <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>");
			}
		}
		catch(Exception excep){
			throw new Exception(excep);
		}
	}

	public CustomException(Exception e, WebDriver driver,String testCaseName) throws Exception {
		String issueType="";
		String exceptionTrace = null;
		try {
			this.driver = driver;

			String strExceptionClass = e.getClass().getCanonicalName().substring(0,
					e.getClass().getCanonicalName().lastIndexOf("."));

			ExceptionFormatter exceptionFormatter = new ExceptionFormatter();

			if (driver != null) {

				for (int i = 0; i < e.getStackTrace().length; i++) {
					if (e.getStackTrace()[i].toString().contains("com.screenmagic")) {

						exceptionTrace = e.getStackTrace()[i].getClassName() + "."
								+ e.getStackTrace()[i].getMethodName()
								+ ":" + e.getStackTrace()[i].getLineNumber();
						break;
					}


				}

				switch (strExceptionClass) {

					case "java.lang":
						issueType="Script Issue";
						throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Script Issue <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

					case "java.io":
						issueType="Script Issue";
						throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Script Issue <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

					case "selenium.common.exceptions":

						String fileName1 = "screenshot" + JavaHelpers.generateRandomNumber() + ".png";
						try {
							File screenshots1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
							FileUtils.copyFile(screenshots1, new File(fileName1));
							File file = new File(screenshots1.getAbsolutePath());

						} finally {
							issueType="Application Issue";
							//FileUtils.forceDelete(file);
							throw new Exception(
									"Exception:" + e.getMessage() + "<br>Issue Type:Application Issue <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));
						}
					case "org.openqa.selenium":
						String fileName2 = "screenshot" + JavaHelpers.generateRandomNumber() + ".png";
						try {
							File screenshots2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
							FileUtils.copyFile(screenshots2, new File(fileName2));
							File file1 = new File(screenshots2.getAbsolutePath());

							//FileUtils.forceDelete(file1);
						} finally {
							issueType="Application Issue";
							throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Application Issue <br>ExceptionTrace:" + exceptionTrace + "<br>"
									+ "Detailed Trace: <br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));
						}
					case "com.screenmagic.customException":
						issueType="Application Issue";
						throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Application Issue <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));

					default:
						String fileName3 = "screenshot" + JavaHelpers.generateRandomNumber() + ".png";
						try {
							File screenshots3 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
							FileUtils.copyFile(screenshots3, new File(fileName3));
							File file2 = new File(screenshots3.getAbsolutePath());

						} finally {
							issueType="Application Issue";
							//FileUtils.forceDelete(file2);
							throw new Exception(
									"Exception:" + e.getMessage() + "<br>Issue Type:Application Issue <br>ExceptionTrace:" + "<br>Detailed Trace:<br>" + exceptionFormatter.toHtml(exceptionFormatter.format(e)));
						}
				}
			} else {
				issueType="Script Issue";
				throw new Exception("Exception:" + e.getMessage() + "<br>Issue Type:Script Issue <br> WebDriver is null <br>ExceptionTrace:" + exceptionTrace + "<br>Detailed Trace:<br>");
			}
		}
		catch(Exception excep){
			CustomExceptionPOJO customExceptionPOJO = new CustomExceptionPOJO();
			customExceptionPOJO.setTestName(testCaseName);
			customExceptionPOJO.setException(excep.getMessage());
			customExceptionPOJO.setIssueType(issueType);
			customExceptionPOJO.setExceptionTrace(exceptionTrace);
			StepDefinition.errorClassified.add(customExceptionPOJO);
			throw new Exception(excep);
		}
	}

	@Override
	public String toString() {
		return message;
	}

	@Override
	public String getMessage() {
		return message;
	}
	public void createVista(WebDriver driver) throws IOException {
		String fileName = getTestName() + ".png";
		File screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenShot, new File("screenshots\\"+fileName));
}

private String getTestName() {
	StackTraceElement packagePath = null;
    StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
    for (int i = 0; i < stacktrace.length; i++) {
    	if(stacktrace[i].toString().contains("com.screenmagic")) {
    		packagePath = stacktrace[i];
    		break;
    	}
    	else if(stacktrace[i].toString().contains("com.screenmagic") )
    		  {
    		packagePath = stacktrace[i];
    		break;
    	}
	}
    String arrayPackageName = packagePath.getMethodName();
    return arrayPackageName;
}

	public String getBase64Html(String fileName) throws IOException {
		FileInputStream inputStream = new FileInputStream(new File(fileName));
		byte imageData[] = new byte[(int) new File(fileName).length()];
		inputStream.read(imageData);
		String imagestring = Base64.getEncoder().encodeToString(imageData);
		inputStream.close();
		new File(fileName).delete();
		return "<div><img src=\"data:image/png;base64," + imagestring + "\"" + " " + "height=" + "\"" + 500 + "\"" + " "
				+ "width=" + "\"" + 500 + "\"" + "></div>";
	} 

	public List<Integer> verifyJar() {
		List<Integer> strs=new ArrayList<Integer>();
		strs.add(5);
		strs.add(7);
		strs.add(10);
		strs.add(4);
		strs.add(5);
		return strs.stream().filter(c->c<10).distinct().collect(Collectors.toList());
	}
	
}
