package com.screen.magic.neo.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class HomePage extends StartupPage {

    @FindBy(className = "switch-to-lightning")
    @CacheLookup
    public WebElement linkSwitchToLight;

    @FindAll({@FindBy(css = ".chartBody"), @FindBy(id = "bodyCell")})
    @CacheLookup
    public WebElement chartHome;

    @FindBy(id = "tryLexDialogX")
    public WebElement dialogueBox;


    public HomePage(WebDriver driver) {
        super(driver);
    }

    public HomePage waitForHomePageToLoad() {
        try {
            webEssentials.waitTillElementIsVisible(chartHome);
        } catch (Exception e) {
        }
        return initializeHomePageLightning();
    }

    public HomePage switchToLightning() {
        try {
            waitForHomePageToLoad();
            if(dialogueBox.isDisplayed()){dialogueBox.click();}

            webEssentials.click(linkSwitchToLight);
        } catch (Exception e) {
            return initializeHomePageLightning();
        }
        return initializeHomePageLightning();
    }


}