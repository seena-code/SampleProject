package com.screen.magic.neo.common.helpers;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.config.EncoderConfig;
import com.jayway.restassured.filter.log.LogDetail;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.screen.magic.neo.common.restAssured.RestUtils;
import com.screen.magic.neo.common.selenium.NGHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

// TODO: Auto-generated Javadoc
/**
 * The Class GetAccessToken.
 */
public class GetAccessToken {
	
	/** The microsoft username ID. */
	String microsoftUsernameID = "cred_userid_inputtext";
	
	/** The microsoft password ID. */
	String microsoftPasswordID = "cred_password_inputtext";
	
	/** The bar usernamecss. */
	String barUsernamecss="#redirect_dots_animation";
	
	/** The microsoft login button ID. */
	String microsoftLoginButtonID = "cred_sign_in_button";
	
	/** The driver. */
	WebDriver driver;
	
	/** The ng helper. */
	NGHelper ngHelper;
	
	/** The access token. */
	public String accessToken;
	
	/** The loader GI fcss. */
	private String loaderGIFcss="span.loadImageText";
	
	/**
	 * Instantiates a new 'get access token'.
	 *
	 * @param driver the driver
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public GetAccessToken(WebDriver driver) throws IOException {
		this.driver = driver;
		ngHelper = new NGHelper(driver);
	}
	
	/**
	 * Use this constructor to get auth-token from API OAuth2 method
	 * @param testData provide testdata, test data map should contain this keys url,client_id,client_secret
	 * @throws Exception the exception
	 */	
	public GetAccessToken(Map<String, String> testData) throws Exception {
		createAccessTokenUsingOAuth(testData);
	}
	
	/**
	 * Use this constructor to get auth-token from API OAuth2 method
	 * @param property provide property,property file should contain this keys url,client_id,client_secret,tenantId
	 * @throws Exception the exception
	 */	
	public GetAccessToken(Properties property) throws Exception {
		if(property.containsKey("environment")) {
			if(property.getProperty("environment").equalsIgnoreCase("microsoft")) {
				createAccessTokenUsingOAuth(property);
			}else if(property.getProperty("environment").equalsIgnoreCase("ibm")){
				createAccessTokenUsingIBMOAuth(property);
			}
		}else {
			createAccessTokenUsingOAuth(property);
		}
	}
	
	/**
	 * Use this constructor when login is not required
	 * Does not need a driver
	 * 
	 */
	
	public GetAccessToken(){
	}
	
	/**
	 * Gets the access token.
	 *
	 * @return the access token
	 */
	public String getAccessToken(){
		return this.accessToken;
	}

	/**
	 * Creates the access token with login.
	 *
	 * @param userName the user name
	 * @param password the password
	 * @throws Exception the exception
	 */
	public void createAccessToken(String userName, String password) throws Exception {
		driver.findElement(By.id( microsoftUsernameID)).sendKeys(userName);
		driver.findElement(By.id( microsoftPasswordID)).sendKeys(password);;
		driver.findElement(By.id("cred_sign_in_button")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("cred_sign_in_button")).click();
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
	    this.accessToken = js.executeScript("return localStorage.access_token").toString();
		driver.close();
	    RestUtils.setAccessToken(accessToken);
	}
	
	
	/**
	 * Creates Access token without login
	
	 * @throws Exception
	 *             throws exception
	 */
	public void createAccessTokenNoLogin() throws Exception {
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
	    this.accessToken = js.executeScript("return localStorage.access_token").toString();
	    RestUtils.setAccessToken(accessToken);
	}
	
	
	/**
	 * Creates Access token using OAuth
	* @param  testData the test data, test data map should contain this keys url,client_id,client_secret
	 * @throws Exception
	 *             throws exception
	 */
	public void createAccessTokenUsingOAuth(Map<String, String> testData) throws Exception {
		this.accessToken = RestAssured
							.given()
							.header("Content-Type", "application/x-www-form-urlencoded")
							.formParam("grant_type", "client_credentials")
							.formParam("client_id", testData.get("client_id"))
							.formParam("client_secret", testData.get("client_secret"))
							.formParam("resource", testData.get("client_id"))
							.post(testData.get("url"))
							.getBody()
							.jsonPath()
							.get("access_token");
		RestUtils.setAccessToken(accessToken);
	}
	
	/**
	 * Creates Access token using OAuth Without Bearer Token
	 * @param  testData the test data, test data map should contain this keys url,tenant_id,app_id,client_id,client_secret,scope,resource
	 * @throws Exception throws exception
	 */
	public String createAccessTokenWithoutBearer(Map<String, String> testData) throws Exception {
		String token = RestAssured
							.given()
							.header("Content-Type", "application/x-www-form-urlencoded")
							.header("TenantId", testData.get("tenant_id"))
							.header("AppId", testData.get("app_id"))
							.formParam("grant_type", "client_credentials")
							.formParam("client_id", testData.get("client_id"))
							.formParam("client_secret", testData.get("client_secret"))
							.formParam("scope", testData.get("scope"))
							.formParam("resource", testData.get("resource"))
							.post(testData.get("url"))
							.getBody()
							.jsonPath()
							.get("access_token");
		return token;
	}
	
	/**
	 * Creates Access token using OAuth
	 * @param  property the test data, property file should contain this keys url,client_id,client_secret,tenantId
	 * @throws Exception throws exception
	 */
	public void createAccessTokenUsingOAuth(Properties property) throws Exception {
		this.accessToken = RestAssured
							.given()
							.header("Content-Type", "application/x-www-form-urlencoded")
							.formParam("grant_type", "client_credentials")
							.formParam("client_id", property.getProperty("client_id"))
							.formParam("client_secret", property.getProperty("client_secret"))
							.formParam("resource", property.getProperty("client_id"))
							.post(property.getProperty("url")+"/"+property.getProperty("tenantId")+"/oauth2/token")
							.getBody()
							.jsonPath()
							.get("access_token");
		RestUtils.setAccessToken(accessToken);
	}
	
	/**
	 * Creates Access token using IBM OAuth
	 * @param  property the test data, property file should contain this keys url,tenantId,client_id,client_secret
	 * @throws Exception throws exception
	 */
	public void createAccessTokenUsingIBMOAuth(Properties property) throws Exception {
		this.accessToken = null;
		Response response = RestAssured.
							given().config(RestAssured.config().encoderConfig(new EncoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
							.header("Content-Type", "application/x-www-form-urlencoded")
							.header("Authorization", "basic " + new String(Base64.getEncoder().encodeToString(
									(property.getProperty("client_id") + ":" + property.getProperty("client_secret")).getBytes())))
							.formParam("grant_type", "client_credentials").formParam("scope", "openid")
							.formParam("client_id", property.getProperty("client_id"))
							.formParam("client_secret", property.getProperty("client_secret"))
							.post(property.getProperty("url") + property.getProperty("tenantId") + "/token");
		JsonPath path = new JsonPath(response.getBody().asString());
		this.accessToken = path.get("access_token");
		RestUtils.setAccessToken(accessToken);
	}
	
	public void createAccessTokenFromInstance_And_Credentials(String sTenantName, String sClientId,
		String sClientSecret, String sEmailAddress, String sPassword) {
		String sAzureEndpoint = "https://login.windows.net/";
		String sTokenURL = null;
		sTokenURL = sAzureEndpoint + sTenantName + "/oauth2/token";
		RequestSpecBuilder builder = new RequestSpecBuilder();
		builder.addHeader("cache-control", "no-cache");
		builder.addHeader("Content-Type", "application/x-www-form-urlencoded");
		builder.setBody("grant_type=password&client_id=" + sClientId + "&resource = " + sClientId + "&client_secret="
				+ sClientSecret + "&userName=" + sEmailAddress + "&password=" + sPassword);
		builder.log(LogDetail.ALL);
		RequestSpecification requestSpec = builder.build();
		Response response = RestAssured.expect().given().spec(requestSpec).post(sTokenURL);
		this.accessToken = response.path("access_token");
	}	
	
	public List<Integer> verifyJar() {
		List<Integer> strs=new ArrayList<Integer>();
		strs.add(5);
		strs.add(7);
		strs.add(10);
		strs.add(4);
		strs.add(5);
		return strs.stream().filter(c->c<10).distinct().collect(Collectors.toList());
	}	
}