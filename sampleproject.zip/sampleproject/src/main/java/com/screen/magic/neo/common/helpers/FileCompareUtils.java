package com.screen.magic.neo.common.helpers;

import de.redsix.pdfcompare.PdfComparator;

import java.io.IOException;

public class FileCompareUtils {
	
	@SuppressWarnings("rawtypes")
	public boolean comparePDF(String expectedFile, String actualFile) throws IOException {
		return new PdfComparator(expectedFile, actualFile).compare().isEqual();
	}

}