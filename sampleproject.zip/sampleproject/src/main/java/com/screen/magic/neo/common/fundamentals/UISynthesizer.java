package com.screen.magic.neo.common.fundamentals;

import org.openqa.selenium.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UISynthesizer {

	WebDriver driver;

	/**
	 * @param driver
	 */
	public UISynthesizer(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * @param tableLocator
	 * @param label
	 * @param charactersTobeRemoved
	 * @return
	 */
	public Map<String, Map<String, WebElement>> getElementMapForLabel(By tableLocator, String label, String... charactersTobeRemoved) {
		try {
			WebElement elem = new WebElementBuilder(new WebEssentials(driver).findTheElement(tableLocator), driver)
					.getWebElement();
			List<WebElement> elems = new WebElementBuilder(elem, driver).getAllElementsUnderWebElement(By.tagName("label"))
																		.getWebElements();
			WebElement element = elems.stream()
									  .filter(el -> new WebEssentials(driver).getTidyString(el.getAttribute("innerText").replace("*", "").trim(),
											  charactersTobeRemoved).equals(label))
									  .findFirst()
									  .orElseThrow(() -> new NoSuchElementException("No Element found with InnerText " + label));
			return verifyAndReturnElementMap(element);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @param tableLocator
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public Map<String, Map<String, WebElement>> tableAbacus(By tableLocator, String... charactersTobeRemoved) throws Exception {
		WebElement elem = new WebElementBuilder(new WebEssentials(driver).findTheElement(tableLocator), driver)
																   .getWebElement();
		List<WebElement> elems = new WebElementBuilder(elem, driver).getAllElementsUnderWebElement(By.tagName("label"))
															.getWebElements();
		Map<String, Map<String, WebElement>> fieldElements = new HashMap<String, Map<String, WebElement>>();
		for (WebElement el : elems) {
			Map<String, WebElement> inputElem = new HashMap<String, WebElement>();
			WebElement check1 = new WebElementBuilder(el, driver).getParentElement().getWebElement();
			WebElement check2 = new WebElementBuilder(el, driver).getParentElement().getNextSiblingElement()
					.getWebElement();
			if (check2 == null) {
				try {
					check2 = new WebElementBuilder(el, driver).getParentElement().getParentElement()
							.getNextSiblingElement().getWebElement();
					if (check2.getTagName().equals("td")) {
						WebElement element = new WebElementBuilder(el, driver).getParentElement().getParentElement()
								.getNextSiblingElement().getWebElement();
						String label = new WebEssentials(driver).getTidyString(el.getAttribute("innerText"), charactersTobeRemoved);
						inputElem.put("checkbox" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='checkbox']")
										.getWebElement());
						inputElem.put("textarea" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("textarea").getWebElement());
						inputElem.put("select" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("select").getWebElement());
						inputElem.put("text" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='text']")
										.getWebElement());
						inputElem.put("link" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("a").getWebElement());
						inputElem.put("image" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("img").getWebElement());
						fieldElements.put(label.toString().replace("*", "").replaceAll(" ", "").trim(),
								inputElem);
					}
				} catch (Exception e) {

				}

			} else {
				if (!check2.getTagName().equalsIgnoreCase("td"))
					check2 = new WebElementBuilder(el, driver).getParentElement().getNextSiblingElement()
							.getWebElement();
				if (check1.getTagName().equals("td") && check2.getTagName().equals("td")) {
					WebElement element = new WebElementBuilder(el, driver).getParentElement().getNextSiblingElement()
							.getWebElement();
					String label = new WebEssentials(driver).getTidyString(el.getAttribute("innerText"), charactersTobeRemoved);
					inputElem.put("checkbox" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='checkbox']")
									.getWebElement());
					inputElem.put("textarea" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("textarea").getWebElement());
					inputElem.put("select" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("select").getWebElement());
					inputElem.put("text" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='text']")
									.getWebElement());
					inputElem.put("link" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("a").getWebElement());
					inputElem.put("image" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("img").getWebElement());
					fieldElements.put(label.toString().replace("*", "").replaceAll(" ", "").trim(), inputElem);
				}
			}
		}
		return fieldElements;
	}

	/**
	 * @param tableElement
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public Map<String, Map<String, WebElement>> tableAbacus(WebElement tableElement, String... charactersTobeRemoved) throws Exception {
		List<WebElement> elems = new WebElementBuilder(tableElement, driver)
				.getAllElementsUnderWebElement(By.tagName("label")).getWebElements();
		Map<String, Map<String, WebElement>> fieldElements = new HashMap<String, Map<String, WebElement>>();
		for (WebElement el : elems) {
			Map<String, WebElement> inputElem = new HashMap<String, WebElement>();
			WebElement check1 = new WebElementBuilder(el, driver).getParentElement().getWebElement();
			WebElement check2 = new WebElementBuilder(el, driver).getParentElement().getNextSiblingElement()
					.getWebElement();
			if (check2 == null) {
				try {
					check2 = new WebElementBuilder(el, driver).getParentElement().getParentElement()
							.getNextSiblingElement().getWebElement();
					if (check2.getTagName().equals("td")) {
						WebElement element = new WebElementBuilder(el, driver).getParentElement().getParentElement()
								.getNextSiblingElement().getWebElement();
						String label = new WebEssentials(driver).getTidyString(el.getAttribute("innerText"));
						inputElem.put("checkbox" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='checkbox']")
										.getWebElement());
						inputElem.put("textarea" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("textarea").getWebElement());
						inputElem.put("select" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("select").getWebElement());
						inputElem.put("text" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='text']")
										.getWebElement());
						inputElem.put("link" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("a").getWebElement());
						inputElem.put("image" + label.toString().replace("*", " ").replace(" ", "").trim(),
								new WebElementBuilder(element, driver).getElementWithDualCSS("img").getWebElement());
						fieldElements.put(label.toString().replace("*", "").replaceAll(" ", "").trim(),
								inputElem);
					}
				} catch (Exception e) {

				}

			} else {
				if (!check2.getTagName().equalsIgnoreCase("td"))
					check2 = new WebElementBuilder(el, driver).getParentElement().getNextSiblingElement()
							.getWebElement();
				if (check1.getTagName().equals("td") && check2.getTagName().equals("td")) {
					WebElement element = (WebElement) ((JavascriptExecutor) driver)
							.executeScript("return arguments[0].parentNode.nextSibling;", el);
					String label = new WebEssentials(driver).getTidyString(el.getAttribute("innerText"), charactersTobeRemoved);
					inputElem.put("checkbox" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='checkbox']")
									.getWebElement());
					inputElem.put("textarea" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("textarea").getWebElement());
					inputElem.put("select" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("select").getWebElement());
					inputElem.put("text" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='text']")
									.getWebElement());
					inputElem.put("link" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("a").getWebElement());
					inputElem.put("image" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("img").getWebElement());
					fieldElements.put(label.toString().replace("*", "").replaceAll(" ", "").trim(), inputElem);
				}
			}
		}
		return fieldElements;
	}

	/**
	 * @param el
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public Map<String, Map<String, WebElement>> verifyAndReturnElementMap(WebElement el, String... charactersTobeRemoved) throws Exception {
		Map<String, Map<String, WebElement>> fieldElements = new HashMap<String, Map<String, WebElement>>();
		Map<String, WebElement> inputElem = new HashMap<String, WebElement>();
		WebElement check1 = new WebElementBuilder(el, driver).getParentElement().getWebElement();
		WebElement check2 = new WebElementBuilder(el, driver).getParentElement().getNextSiblingElement()
				.getWebElement();
		if (check2 == null) {
			try {
				check2 = new WebElementBuilder(el, driver).getParentElement().getParentElement().getNextSiblingElement()
						.getWebElement();
				if (check2.getTagName().equals("td")) {
					WebElement element = new WebElementBuilder(el, driver).getParentElement().getParentElement()
							.getNextSiblingElement().getWebElement();
					String label = new WebEssentials(driver).getTidyString(el.getAttribute("innerText"), charactersTobeRemoved);
					inputElem.put("checkbox" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='checkbox']")
									.getWebElement());
					inputElem.put("textarea" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("textarea").getWebElement());
					inputElem.put("select" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("select").getWebElement());
					inputElem.put("text" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='text']")
									.getWebElement());
					inputElem.put("link" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("a").getWebElement());
					inputElem.put("image" + label.toString().replace("*", " ").replace(" ", "").trim(),
							new WebElementBuilder(element, driver).getElementWithDualCSS("img").getWebElement());
					fieldElements.put(label.toString().replace("*", "").replaceAll(" ", "").trim(), inputElem);
				}
			} catch (Exception e) {

			}

		} else {
			if (!check2.getTagName().equalsIgnoreCase("td"))
				check2 = new WebElementBuilder(el, driver).getParentElement().getNextSiblingElement().getWebElement();
			if (check1.getTagName().equals("td") && check2.getTagName().equals("td")) {
				WebElement element = (WebElement) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].parentNode.nextSibling;", el);
				String label = new WebEssentials(driver).getTidyString(el.getAttribute("innerText"), charactersTobeRemoved);
				inputElem.put("checkbox" + label.toString().replace("*", " ").replace(" ", "").trim(),
						new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='checkbox']")
								.getWebElement());
				inputElem.put("textarea" + label.toString().replace("*", " ").replace(" ", "").trim(),
						new WebElementBuilder(element, driver).getElementWithDualCSS("textarea").getWebElement());
				inputElem.put("select" + label.toString().replace("*", " ").replace(" ", "").trim(),
						new WebElementBuilder(element, driver).getElementWithDualCSS("select").getWebElement());
				inputElem.put("text" + label.toString().replace("*", " ").replace(" ", "").trim(),
						new WebElementBuilder(element, driver).getElementWithDualCSS("input[type='text']").getWebElement());
				inputElem.put("link" + label.toString().replace("*", " ").replace(" ", "").trim(),
						new WebElementBuilder(element, driver).getElementWithDualCSS("a").getWebElement());
				inputElem.put("image" + label.toString().replace("*", " ").replace(" ", "").trim(),
						new WebElementBuilder(element, driver).getElementWithDualCSS("img").getWebElement());
				fieldElements.put(label.toString().replace("*", "").replaceAll(" ", "").trim(), inputElem);
			}
		}
		return fieldElements;
	}

}