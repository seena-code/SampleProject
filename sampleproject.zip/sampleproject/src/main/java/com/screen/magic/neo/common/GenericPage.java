package com.screen.magic.neo.common;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GenericPage extends StartupPage {
    public int waitTime = 40;

    public GenericPage(WebDriver driver) {
        super(driver);
        webEssentials.setWaitTime(60);
    }

    public boolean checkVisibility(WebElement element) throws Exception {
        webEssentials.waitTillElementIsVisible(element);
        return webEssentials.checkVisibility(element);
    }

    public boolean checkInVisibility(WebElement element) throws Exception {
        boolean isExists = false;
        try {
            isExists = webEssentials.checkVisibility(element);
            return isExists;
        } catch (NoSuchElementException | StaleElementReferenceException e) {
            return false;
        }
    }

    public void doubleClick(WebElement element) throws Exception {
        Actions builder = new Actions(driver);
        try {
            webEssentials.waitTillElementIsVisible(element);
            builder.doubleClick(element).build().perform();
        } catch (Exception e) {
        }
    }

    public void refreshPage() throws Exception {
        webEssentials.refreshPage();
    }

    public void refreshPage(WebElement element) throws Exception {
        webEssentials.refreshPage();
        waitTillStaleElementToBeVisible(element);
        webEssentials.waitTillElementIsVisible(element);
    }

    public void clearField(WebElement eleToClear) throws Exception {
        webEssentials.waitTillElementIsVisible(eleToClear);
        eleToClear.sendKeys(Keys.CONTROL + "a");
        eleToClear.sendKeys(Keys.DELETE);
    }


    public void deleteTempDirectory() {
        try {
            File tempDirectory = new File(System.getProperty("user.dir") + File.separator + "temp" + File.separator);
            ;
            if (tempDirectory.exists())
                FileUtils.deleteDirectory(tempDirectory);
        } catch (IOException e) {
        }
    }

    public String getCurrentUrl() throws Exception {
        return webEssentials.getCurrentURL();
    }

    public String splitString(String textString, String splitText, int index) throws Exception {
        return textString.split(splitText)[index].trim();
    }

    public GenericPage checkInnerTextMatches(WebElement element, String value) throws Exception {
        webEssentials.waitTillInnerTextMatches(element, value);
        return initializeGenericPage();
    }

    public String getAttributeValue(WebElement field, String attributeName) throws Exception {
        webEssentials.waitTillElementIsVisible(field);
        return field.getAttribute(attributeName);
    }



    public void navigateURL(String URL, String uniqueId, WebElement element) throws Exception {
        webEssentials.navigateTo(URL + uniqueId);
        webEssentials.waitTillElementIsVisible(element);
    }


    public void waitTillStaleElementToBeVisible(WebElement ele) {
        new WebDriverWait(driver, waitTime)
                .until(ExpectedConditions.refreshed(
                        ExpectedConditions.visibilityOf(ele)));
    }

    public GenericPage waitUntilTitleChanges(String title) throws Exception {
        Instant start = Instant.now();
        Boolean found = false;
        while (found == false) {
            Instant now = Instant.now();
            if (Duration.between(start, now).toMillis() >= 30000) {
                found = true;
                break;
            }
            try {
                if (webEssentials.getTitle().contains(title)) {
                    found = true;
                }
            } catch (NoSuchElementException e) {
                found = false;
            }
        }
        return initializeGenericPage();
    }

    public boolean checkURL(String subString) throws Exception {
        return webEssentials.getCurrentURL().contains(subString) ? true : false;
    }

    public boolean comparingPattern(String substring) throws Exception{

        Pattern pattern = Pattern.compile(".*" + substring + ".*");

        Matcher matcher = pattern.matcher(webEssentials.getCurrentURL());

        return matcher.find();
    }

    public void scrollToTextArea() {
        webEssentials.scroll();
    }


}