package com.screen.magic.neo.common.restAssured;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class RestHelper {
	
	private String accessToken;

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	/**
	 * Fetches the data
	 * 
	 * @param url     provide valid URL
	 * @param headers Provide valid Headers's Key and value in Map
	 * @return API response
	 */
	public Response get(String url, Map<String, String> headers) {
		RequestSpecBuilder builder = new RequestSpecBuilder();
		for (Map.Entry<String, String> headerItr : headers.entrySet()) {
			builder.addHeader(headerItr.getKey().trim(), headerItr.getValue().trim());
		}
		RequestSpecification requestSpec = builder.build();
		return RestAssured.expect().given().spec(requestSpec).get(url);
	}

	/**
	 * Fetches the data
	 * 
	 * @param url provide valid URL
	 * @body body provide valid body
	 * @param headers Provide valid Headers's Key and value in Map
	 * @return API response
	 */
	public Response get(String url, String body, Map<String, String> headers) {
		RequestSpecBuilder builder = new RequestSpecBuilder();
		for (Map.Entry<String, String> headerItr : headers.entrySet()) {
			builder.addHeader(headerItr.getKey().trim(), headerItr.getValue().trim());
		}
		builder.setBody(body);
		RequestSpecification requestSpec = builder.build();
		return RestAssured.expect().given().spec(requestSpec).get(url);
	}

	/**
	 * Create the data
	 * 
	 * @param url     provide valid URL
	 * @param body    Provide the body
	 * @param headers Provide valid Headers's Key and value in Map
	 * @return API response
	 */
	public Response post(String url, String body, Map<String, String> headers) {
		RequestSpecBuilder builder = new RequestSpecBuilder();
		for (Map.Entry<String, String> headerItr : headers.entrySet()) {
			builder.addHeader(headerItr.getKey().trim(), headerItr.getValue().trim());
		}
		builder.setBody(body);
		RequestSpecification requestSpec = builder.build();
		return RestAssured.expect().given().spec(requestSpec).post(url);
	}

	/**
	 * Create the data
	 * 
	 * @param url           provide valid URL
	 * @param headers       Provide valid Headers's Key and value in Map
	 * @param multipartData Provide valid Multipart's key,value and type in ArrayList of Map
	 * @return API response
	 */
	public Response post(String url,Map<String, String> headers,ArrayList<Map<String, String>> multipartData) {
		RequestSpecBuilder builder = new RequestSpecBuilder();
		for (Map.Entry<String, String> headerItr : headers.entrySet()) {
			builder.addHeader(headerItr.getKey().trim(), headerItr.getValue().trim());
		}
		for(int i=0;i<multipartData.size();i++) {
				if(multipartData.get(i).get("type").trim().equalsIgnoreCase("file")) {
					builder.addMultiPart(multipartData.get(i).get("key").trim(), new File(multipartData.get(i).get("value").trim()));
				}else {
					builder.addMultiPart(multipartData.get(i).get("key").trim(), multipartData.get(i).get("value").trim());
				}
		}
		RequestSpecification requestSpec = builder.build();
		return RestAssured.expect()
				.given()
				.spec(requestSpec)
				.post(url);
	}

	/**
	 * Create the data
	 * 
	 * @param url     provide valid URL
	 * @param body    Provide the body
	 * @param headers Provide valid Headers's Key and value in Map
	 * @return API response
	 */
	public Response post(String url, Map<String, String> headers) {
		RequestSpecBuilder builder = new RequestSpecBuilder();
		for (Map.Entry<String, String> headerItr : headers.entrySet()) {
			builder.addHeader(headerItr.getKey().trim(), headerItr.getValue().trim());
		}
		RequestSpecification requestSpec = builder.build();
		return RestAssured.expect().given().spec(requestSpec).post(url);
	}

	/**
	 * Updates the data
	 * 
	 * @param url     provide valid URL
	 * @param body    Provide the body
	 * @param headers Provide valid Headers's Key and value in Map
	 * @return API response
	 */
	public Response put(String url, String body, Map<String, String> headers) {
		RequestSpecBuilder builder = new RequestSpecBuilder();
		for (Map.Entry<String, String> headerItr : headers.entrySet()) {
			builder.addHeader(headerItr.getKey().trim(), headerItr.getValue().trim());
		}
		builder.setBody(body);
		RequestSpecification requestSpec = builder.build();
		return RestAssured.expect().given().spec(requestSpec).put(url);
	}

	/**
	 * Update the data
	 * 
	 * @param url           provide valid URL
	 * @param headers       Provide valid Headers's Key and value in Map
	 * @param multipartData Provide valid Multipart's key,value and type in ArrayList of Map
	 * @return API response
	 */
	public Response put(String url, Map<String,String> headers,ArrayList<Map<String, String>> multipartData) {
		RequestSpecBuilder builder = new RequestSpecBuilder();
		for (Map.Entry<String, String> headerItr : headers.entrySet()) {
			builder.addHeader(headerItr.getKey().trim(), headerItr.getValue().trim());
		}
		for (int i = 0; i < multipartData.size(); i++) {
			if (multipartData.get(i).get("type").trim().equalsIgnoreCase("file")) {
				builder.addMultiPart(multipartData.get(i).get("key").trim(),new File(multipartData.get(i).get("value").trim()));
			} else {
				builder.addMultiPart(multipartData.get(i).get("key").trim(), multipartData.get(i).get("value").trim());
			}
		}
		RequestSpecification requestSpec = builder.build();
		return RestAssured.expect()
				.given()
				.spec(requestSpec)
				.put(url);
	}

	/**
	 * Deletes the data
	 * 
	 * @param url     provide valid URL
	 * @param headers Provide valid Headers's Key and value in Map
	 * @return API response
	 */
	public Response delete(String url, Map<String, String> headers) {
		RequestSpecBuilder builder = new RequestSpecBuilder();
		for (Map.Entry<String, String> headerItr : headers.entrySet()) {
			builder.addHeader(headerItr.getKey().trim(), headerItr.getValue().trim());
		}
		RequestSpecification requestSpec = builder.build();
		return RestAssured.expect().given().spec(requestSpec).delete(url);
	}
	
	public List<Integer> verifyJar() {
		List<Integer> strs=new ArrayList<Integer>();
		strs.add(5);
		strs.add(7);
		strs.add(10);
		strs.add(4);
		strs.add(5);
		return strs.stream().filter(c->c<10).distinct().collect(Collectors.toList());
	}

}
