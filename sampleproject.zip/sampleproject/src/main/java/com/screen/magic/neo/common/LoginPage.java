package com.screen.magic.neo.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends StartupPage {

    @FindBy(id="Login")
    private WebElement btnLogin;

    @FindBy(id="username")
    private WebElement txtUserName;

    @FindBy(xpath="//a[@title='Home']|//*[@id='home_Tab']")
    private WebElement tabHomeid;

    @FindBy(xpath="//*[@title='Home']|//*[@id='home_Tab']")
    public WebElement homeTab;

    @FindBy(id="password")
    private WebElement txtPassword;

    @FindBy(xpath="//a[@class='switch-to-lightning']")
    private WebElement btnLightening;

    @FindAll({@FindBy(css=".chartBody"),@FindBy(id="bodyCell")})
    public WebElement chartHome;



    public GenericPage genericPage;

    public LoginPage(WebDriver driver) {
        super(driver);
        genericPage = initializeGenericPage();
    }

    public LoginPage waitForLoginPageLoad() throws Exception{

            webEssentials.waitTillElementIsVisible(btnLogin)
                    .waitTillElementIsClickable(btnLogin);

        return initializeLoginPage();
    }

    public HomePage loginToApp(String userName, String password) throws Exception {

        webEssentials.waitTillElementIsVisible(txtUserName)
                .clear(txtUserName)
                .clear(txtPassword);
        txtUserName.sendKeys(userName);
        txtPassword.sendKeys(password);
        btnLogin.click();
        webEssentials.waitTillElementIsVisible(tabHomeid)
                .waitTillElementIsClickable(tabHomeid)
                .moveToElementAndClick(tabHomeid);
        genericPage.waitUntilTitleChanges(CommonTestData.homePageTitle);
        webEssentials.waitTillElementIsVisible(chartHome);

        return initializeHomePageLightning();
    }
}
