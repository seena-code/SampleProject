package com.screen.magic.neo.common.fundamentals;

import com.github.javafaker.Faker;
import com.screen.magic.neo.common.helpers.Efficacies;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.text.SimpleDateFormat;
import java.util.NoSuchElementException;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;


public class WebEssentials {

	public WebDriver driver;
	public static Integer WaitTime = 10;
	public WebDriverWait webDriverWait;

	/**
	 * Method to retrieve configured wait time.
	 * 
	 * @return
	 */
	public Integer getWaitTime() {
		return WaitTime;
	}

	/**
	 * Method to Configure wait time.
	 * 
	 * @param waitTime
	 */
	public void setWaitTime(Integer waitTime) {
		WaitTime = waitTime;
	}

	/**
	 * Method to get Combo box WebElement on pop up using the label.
	 * 
	 * @param label
	 * @return WebElement found with the label 
	 * @throws Exception
	 */
	public WebElement getComboBoxFieldOnPopUp(String label) throws Exception {
		return new WebElementBuilder(driver).getElementWithCSSText("span.label span", label).getParentElement()
				.getNextSiblingElement().getElementWithDualCSS("a").getWebElement();
	}

	/**
	 * Method to get WebElement using label and CSS path
	 * 
	 * @param label
	 * @param csspath
	 * @return
	 * @throws Exception
	 */
	public WebElement getAnyElementOnPopUpUnderLabel(String label, String csspath) throws Exception {
		return new WebElementBuilder(driver).getElementWithCSSText("span", label).getParentElement()
				.getNextSiblingElement().getElementWithDualCSS(csspath).getWebElement();
	}

	/**
	 * @param label
	 * @return
	 * @throws Exception
	 */
	public WebElement getSearchIconOnPopUp(String label) throws Exception {
		return new WebElementBuilder(driver).getElementWithCSSText("span", label).getParentElement()
				.getElementWithDualCSS("input").getParentElement().getNextSiblingElement().getWebElement();
	}

	/**
	 * @param label
	 * @return
	 * @throws Exception
	 */
	public WebElement getTextFieldOnPopUp(String label) throws Exception {
		return new WebElementBuilder(driver).getElementWithCSSText("span", label).getParentElement()
				.getElementWithDualCSS("input").getWebElement();
	}

	/**
	 * @param label
	 * @return
	 * @throws Exception
	 */
	public WebElement getTextFieldElementWithLabel(String label) throws Exception {
		return new WebElementBuilder(driver).getElementWithCSSText("label", label).getParentElement()
				.getNextSiblingElement().getElementWithDualCSS("input").getWebElement();
	}

	/**
	 * @param label
	 * @return
	 * @throws Exception
	 */
	public WebElement getLookUpElementWithLabel(String label) throws Exception {
		return new WebElementBuilder(driver).getElementWithCSSText("label", label).getParentElement()
				.getNextSiblingElement().getElementWithDualCSS("a").getWebElement();
	}

	/**
	 * @param label
	 * @return
	 * @throws Exception
	 */
	public WebElement getComboboxElementWithLabel(String label) throws Exception {
		return new WebElementBuilder(driver).getElementWithCSSText("label", label).getParentElement()
				.getNextSiblingElement().getElementWithDualCSS("select").getWebElement();
	}

	/**
	 * @param label
	 * @return
	 * @throws Exception
	 */
	public WebElement getDateFieldElementWithLabel(String label) throws Exception {
		return new WebElementBuilder(driver).getElementWithCSSText("label", label).getParentElement()
				.getNextSiblingElement().getElementWithDualCSS("input").getWebElement();
	}

	/**
	 * @param searchText
	 * @return
	 * @throws Exception
	 */
	public WebEssentials performSearchInLookup(String searchText) throws Exception {
		Set<String> handles = getWindowHandles();
		List<String> lstHandles = new ArrayList<>(handles);
		switchToWindow(lstHandles.get(1));
		waitTillFrameIsAvailableAndSwitch(findTheElement(By.id("searchFrame")));
		waitTillInnerTextMatches(By.cssSelector(".assistiveText"), "Search");
		waitTillElementIsClickable(By.cssSelector("[type='submit']"));
		waitTillElementIsVisible(By.id("lksrch"));
		waitTillElementIsClickable(By.id("lksrch"));
		WebElement webElement = findTheElement(By.id("lksrch"));
		sendKeysTo(webElement, searchText);
		jsClick(findTheElement(By.cssSelector("[type='submit']")));
		driver.switchTo().defaultContent();
		waitTillFrameIsAvailableAndSwitch(findTheElement(By.id("resultsFrame")));
		waitTillElementIsVisible(By.tagName("table"));
		jsClick(findTheElement(By.linkText(searchText)));
		switchToWindow(lstHandles.get(0));
		return new WebEssentials(driver);
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public String genRandomNumber() throws Exception {
		return Long.toString(new Efficacies().generateRandomNumber());
	}

	/**
	 * @param lines
	 * @return
	 * @throws Exception
	 */
	public String genParagraph(int lines) throws Exception {
		return new Faker(new Locale("en")).lorem().paragraph(lines);
	}

	/**
	 * @param driver
	 */
	public WebEssentials(WebDriver driver) {
		this.driver = driver;
		webDriverWait = new WebDriverWait(driver, WaitTime);
	}
	

	/**
	 * @param elem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials click(WebElement elem) throws Exception {
		if(((RemoteWebDriver)driver).getCapabilities().getBrowserName().equalsIgnoreCase("safari")) {
			jsClick(elem);
			return new WebEssentials(driver);
		}
		elem.click();
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials click(By byElem) throws Exception {
		if(((RemoteWebDriver)driver).getCapabilities().getBrowserName().equalsIgnoreCase("safari")) {
			jsClick(findTheElement(byElem));
			return new WebEssentials(driver);
		}
		findTheElement(byElem).click();
		return new WebEssentials(driver);
	}

	/**
	 * @param elem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials clear(WebElement elem) throws Exception {
		elem.clear();
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials clear(By byElem) throws Exception {
		driver.findElement(byElem).clear();
		return new WebEssentials(driver);
	}

	/**
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public WebEssentials navigateTo(String url) throws Exception {
		driver.get(url);
		return new WebEssentials(driver);
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebEssentials refreshPage() throws Exception {
		driver.navigate().refresh();
		return new WebEssentials(driver);
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	public String getCurrentURL() throws Exception {
		return driver.getCurrentUrl();
    }
	
	/**
	 * @return
	 * @throws Exception
	 */
	public String getTitle() throws Exception {
    	return driver.getTitle();
    }

	/**
	 * @return
	 * @throws Exception
	 */
	public WebEssentials maximizeWindow() throws Exception {
		driver.manage().window().maximize();
		return new WebEssentials(driver);
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public Set<String> getWindowHandles() throws Exception {
		return driver.getWindowHandles();
	}

	/**
	 * @param handle
	 * @return
	 * @throws Exception
	 */
	public WebEssentials switchToWindow(String handle) throws Exception {
		driver.switchTo().window(handle);
		return new WebEssentials(driver);
	}

	/**
	 * @param elem
	 * @param inputString
	 * @return
	 * @throws Exception
	 */
	public WebEssentials sendKeysTo(WebElement elem, String inputString) throws Exception {
		elem.sendKeys(inputString);
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @param inputString
	 * @return
	 * @throws Exception
	 */
	public WebEssentials sendKeysTo(By byElem, String inputString) throws Exception {
		driver.findElement(byElem).sendKeys(inputString);
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebElement findTheElement(By byElem) throws Exception {
		return driver.findElement(byElem);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public List<WebElement> findTheElements(By byElem) throws Exception {
		return driver.findElements(byElem);
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials jsClick(WebElement element) throws Exception {
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials jsClick(By byElem) throws Exception {
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", findTheElement(byElem));
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials jsScroll(WebElement element) throws Exception {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials jsScroll(By byElem) throws Exception {
		WebElement element = findTheElement(byElem);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials jsScrollAndClick(WebElement element) throws Exception {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		jsClick(element);
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials jsScrollAndClick(By byElem) throws Exception {
		WebElement element = findTheElement(byElem);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		jsClick(element);
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillElementIsVisible(WebElement element) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(element)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillElementIsVisible(By byElem) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.presenceOfElementLocated(byElem)));
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillElementIsClickable(WebElement element) throws Exception {

		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.elementToBeClickable(element)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillElementIsClickable(By byElem) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.elementToBeClickable(byElem)));
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillElementIsInvisible(WebElement element) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.invisibilityOf(element)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillElementIsInvisible(By byElem) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.invisibilityOfElementLocated(byElem)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillFrameIsAvailableAndSwitch(By byElem) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.frameToBeAvailableAndSwitchToIt(byElem)));
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillFrameIsAvailableAndSwitch(WebElement element) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.frameToBeAvailableAndSwitchToIt(element)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @param pattern
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillInnerTextMatches(By byElem, Pattern pattern) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.textMatches(byElem, pattern)));
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @param innerText
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillInnerTextMatches(WebElement element, String innerText) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.textToBePresentInElement(element, innerText)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @param innerText
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillInnerTextMatches(By byElem, String innerText) throws Exception {
		webDriverWait
				.until(ExpectedConditions.or(ExpectedConditions.textToBePresentInElementLocated(byElem, innerText)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillValueMatches(By byElem, String value) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.textToBePresentInElementValue(byElem, value)));
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillValueMatches(WebElement element, String value) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.textToBePresentInElementValue(element, value)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @param innerText
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillTextIsInvisible(By byElem, String innerText) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, WaitTime);
		wait.until(ExpectedConditions.or(ExpectedConditions.invisibilityOfElementWithText(byElem, innerText)));
		return new WebEssentials(driver);
	}
	
	/**
	 * @param element
	 * @param innerText
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillTextIsInvisible(WebElement element, String innerText) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, WaitTime);
		wait.until(ExpectedConditions.or(ExpectedConditions.textToBePresentInElement(element, innerText)));
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @param attribute
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillAttributeContains(WebElement element, String attribute, String value) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.attributeContains(element, attribute, value)));
		return new WebEssentials(driver);
	}

	public WebEssentials waitTillTextToBe(WebElement element, String value) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.textToBePresentInElement(element, value)));
		return new WebEssentials(driver);
	}
	/**
	 * @param byElem
	 * @param attribute
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillAttributeContains(By byElem, String attribute, String value) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.attributeContains(byElem, attribute, value)));
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @param attribute
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillAttributeMatches(WebElement element, String attribute, String value) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.attributeToBe(element, attribute, value)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @param attribute
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillAttributeMatches(By byElem, String attribute, String value) throws Exception {
		webDriverWait.until(ExpectedConditions.or(ExpectedConditions.attributeToBe(byElem, attribute, value)));
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @param attribute
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public String getAttribute(WebElement element, String attribute) throws Exception {

		return element.getAttribute(attribute);
	}


	/**
	 * @param elements
	 * @param charactersTobeRemoved (Optional parameter)
	 * @return
	 * @throws Exception
	 */
	public List<String> returnInnertext(List<WebElement> elements, String... charactersTobeRemoved) throws Exception {
		return elements.stream().map(e->new WebEssentials(driver).getTidyString(e.getAttribute("innerText"),charactersTobeRemoved)).collect(Collectors.toList());
	}

	/**
	 * @param buttonText
	 * @param charactersTobeRemoved (Optional parameter)
	 * @return
	 * @throws Exception
	 */
	public WebElement clickButtonWithText(String buttonText, String... charactersTobeRemoved) throws Exception {
		List<WebElement> elems = driver.findElements(By.tagName("button"));
		WebElement element = elems.stream().filter(elem -> new WebEssentials(driver).getTidyString(elem.getAttribute("innerText"),
											charactersTobeRemoved).equals(buttonText)).findFirst()
				.orElseThrow(() -> new NoSuchElementException("Button with text " + buttonText + " is not Found"));
		return element;
	}

	/**
	 * @param buttonText
	 * @param charactersTobeRemoved (Optional parameter)
	 * @return
	 * @throws Exception
	 */
	public WebElement clickInputButtonWithText(String buttonText, String... charactersTobeRemoved) throws Exception {
		List<WebElement> elems = driver.findElements(By.cssSelector("input[type='button']"));
		WebElement element = elems.stream().filter(elem -> new WebEssentials(driver).getTidyString(elem.getAttribute("innerText"),
											charactersTobeRemoved).equals(buttonText)).findFirst()
				.orElseThrow(() -> new NoSuchElementException("Button with text " + buttonText + " is not Found"));
		return element;
	}

	/**
	 * @param partialButtonText
	 * @param charactersTobeRemoved (Optional parameter)
	 * @return
	 * @throws Exception
	 */
	public WebElement clickButtonContainingText(String partialButtonText, String... charactersTobeRemoved) throws Exception {
		List<WebElement> elems = driver.findElements(By.tagName("button"));
		WebElement element = elems.stream().filter(elem -> new WebEssentials(driver).getTidyString(elem.getAttribute("innerText"),
											charactersTobeRemoved).contains(partialButtonText))
				.findFirst().orElseThrow(() -> new NoSuchElementException(
						"Button with Partial text " + partialButtonText + " is not Found"));
		return element;
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials mouseHover(WebElement element) throws Exception {
		Actions actions = new Actions(driver);
		actions.moveToElement(element).build().perform();
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials moveToElementAndClick(WebElement element) throws Exception {
		Actions actions = new Actions(driver);
		actions.moveToElement(element).click().build().perform();
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials moveToElementAndClick(By byElem) throws Exception {
		Actions actions = new Actions(driver);
		actions.moveToElement(findTheElement(byElem)).click().build().perform();
		return new WebEssentials(driver);
	}

	/**
	 * @param elem
	 * @param string
	 * @return
	 * @throws Exception
	 */
	public WebEssentials clickAndSendkeys(WebElement elem, String string) throws Exception {
		elem.click();
		elem.sendKeys(string);
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @param string
	 * @return
	 * @throws Exception
	 */
	public WebEssentials clickAndSendkeys(By byElem, String string) throws Exception {
		findTheElement(byElem).click();
		findTheElement(byElem).sendKeys(string);
		return new WebEssentials(driver);
	}

	/**
	 * @param elem
	 * @return
	 * @throws Exception
	 */
	public String retrieveValueJS(WebElement elem) throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		return js.executeScript("return arguments[0].value", elem).toString();
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public String retrieveValueJS(By byElem) throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		return js.executeScript("return arguments[0].value", findTheElement(byElem)).toString();
	}

	/**
	 * @param element
	 * @return
	 */
	public Boolean checkVisibility(WebElement element) {
		boolean visible = false;
		try {
			if (element.isDisplayed() == true) {
				visible = true;
			}
		} catch (NoSuchElementException noexcep) {
			visible = false;
		}
		return visible;
	}

	/**
	 * @param element
	 * @return
	 */
	public Boolean checkSelected(WebElement element) {
		boolean selected = false;
		try {
			if (element.isSelected() == true) {
				selected = true;
			}
		} catch (NoSuchElementException noexcep) {
			selected = false;
		}
		return selected;
	}

	/**
	 * @param element
	 * @return
	 */
	public Boolean checkEnabled(WebElement element) {
		boolean selected = false;
		try {
			if (element.isEnabled() == true) {
				selected = true;
			}
		} catch (NoSuchElementException noexcep) {
			selected = false;
		}
		return selected;
	}

	/**
	 * @param element
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillElementIsSelected(WebElement element) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, WaitTime);
		wait.until(ExpectedConditions.or(ExpectedConditions.elementToBeSelected(element)));
		return new WebEssentials(driver);
	}

	/**
	 * @param byElem
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillElementIsSelected(By byElem) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, WaitTime);
		wait.until(ExpectedConditions.or(ExpectedConditions.elementToBeSelected(byElem)));
		return new WebEssentials(driver);
	}

	/**
	 * @param source
	 * @param target
	 * @return
	 * @throws Exception
	 */
	public WebEssentials performDragAndDrop(WebElement source, WebElement target) throws Exception {
		Actions actions = new Actions(driver);
		actions.dragAndDrop(source, target).build().perform();
		return new WebEssentials(driver);
	}

	/**
	 * @param source
	 * @param destination
	 * @return
	 * @throws Exception
	 */
	public WebEssentials performDragAndDropJS(WebElement source, WebElement destination) throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript(
				"function createEvent(typeOfEvent) " + "{\n" + "var event =document.createEvent(\"CustomEvent\");\n"
						+ "event.initCustomEvent(typeOfEvent,true, true, null);\n" + "event.dataTransfer = {\n"
						+ "data: {},\n" + "setData: function (key, value) {\n" + "this.data[key] = value;\n" + "},\n"
						+ "getData: function (key) {\n" + "return this.data[key];\n" + "}\n" + "};\n"
						+ "return event;\n" + "}\n" + "\n" + "function dispatchEvent(element, event,transferData) "
						+ "{\n" + "if (transferData !== undefined) " + "{\n" + "event.dataTransfer = transferData;\n"
						+ "}\n" + "if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n" + "} "
						+ "else if (element.fireEvent) {\n" + "element.fireEvent(\"on\" + event.type, event);\n" + "}\n"
						+ "}\n" + "\n" + "function simulateHTML5DragAndDrop(element, destination) {\n"
						+ "var dragStartEvent =createEvent('dragstart');\n"
						+ "dispatchEvent(element, dragStartEvent);\n" + "var dropEvent = createEvent('drop');\n"
						+ "dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n"
						+ "var dragEndEvent = createEvent('dragend');\n"
						+ "dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" + "}\n" + "\n"
						+ "var source = arguments[0];\n" + "var destination = arguments[1];\n"
						+ "simulateHTML5DragAndDrop(source,destination);",
				source, destination);
		return new WebEssentials(driver);
	}

	/**
	 * @param source
	 * @param xOffset
	 * @param yOffset
	 * @return
	 * @throws Exception
	 */
	public WebEssentials performDragAndDropCoordinates(WebElement source, int xOffset, int yOffset) throws Exception {
		Actions actions = new Actions(driver);
		actions.dragAndDropBy(source, xOffset, yOffset).build().perform();
		return new WebEssentials(driver);
	}

	/**
	 * @return
	 */
	public WebEssentials switchToDefaultContent() {
		driver.switchTo().defaultContent();
		return new WebEssentials(driver);
	}

	/**
	 * @param dateFormat
	 * @return
	 */
	public String returnTodaysDate(String dateFormat) {
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		Date date = new Date();
		return formatter.format(date);
	}

	/**
	 * @param dateFormat
	 * @param days
	 * @return
	 */
	public String returnFutureDate(String dateFormat, int days) {
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, days);
		return formatter.format(c.getTime());
	}

	/**
	 * @param key
	 * @return
	 */
	public WebEssentials sendBoardKeys(Keys key) {
		Actions acc = new Actions(driver);
		acc.sendKeys(key).build().perform();
		return new WebEssentials(driver);
	}

	/**
	 * @param textString
	 * @return
	 * @throws Exception
	 */
	public WebEssentials sendTextKeys(String textString) throws Exception {
		Actions acc = new Actions(driver);
		acc.sendKeys(textString).build().perform();
		return new WebEssentials(driver);
	}

	/**
	 * @param comboElement
	 * @param visibleText
	 * @return
	 * @throws Exception
	 */
	public WebEssentials selectComboByText(WebElement comboElement, String visibleText) throws Exception {
		Select select = new Select(comboElement);
		//select.selectByVisibleText(visibleText);
		return new WebEssentials(driver);
	}

	/**
	 * @param comboElement
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public WebEssentials selectComboByValue(WebElement comboElement, String value) throws Exception {
		Select select = new Select(comboElement);
		select.selectByValue(value);
		return new WebEssentials(driver);
	}

	/**
	 * @param comboElement
	 * @param index
	 * @return
	 * @throws Exception
	 */
	public WebEssentials selectComboByIndex(WebElement comboElement, Integer index) throws Exception {
		Select select = new Select(comboElement);
		select.selectByIndex(index);
		return new WebEssentials(driver);
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebEssentials waitTillAlertIsDisplayed() throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, WaitTime);
		wait.until(ExpectedConditions.or(ExpectedConditions.alertIsPresent()));
		return new WebEssentials(driver);
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebEssentials acceptAlert() throws Exception {
		Alert alert = driver.switchTo().alert();
		alert.accept();
		return new WebEssentials(driver);
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebEssentials dismissAlert() throws Exception {
		Alert alert = driver.switchTo().alert();
		alert.dismiss();
		return new WebEssentials(driver);
	}

	/**
	 * @param element
	 * @param xcoordinate
	 * @param Ycoordinate
	 * @return
	 * @throws Exception
	 */
	public WebEssentials moveElementToOrdinates(WebElement element, Integer xcoordinate, Integer Ycoordinate)
			throws Exception {
		Point point = element.getLocation();
		Integer xcord = point.getX();
		Integer ycord = point.getY();
		Actions actions = new Actions(driver);
		actions.clickAndHold().moveByOffset(xcord + xcoordinate, ycord + Ycoordinate).release().build().perform();
		return new WebEssentials(driver);
	}
	
	/**
	 * @param element
	 * @return
	 */
	public String jsGetInnerText(WebElement element) {
		JavascriptExecutor js=((JavascriptExecutor)driver);
		return (String)js.executeScript("return arguments[0].innerText;", element);
	}
	
	/**
	 * @param element
	 * @return
	 */
	public String jsGetTextContent(WebElement element) {
		JavascriptExecutor js=((JavascriptExecutor)driver);
		return (String)js.executeScript("return arguments[0].textContent;", element);
	}
	
	/**
	 * @param byElem
	 * @return
	 */
	public WebEssentials waitTillElementIsAvailableInDOM(By byElem) {
		new WebDriverWait(driver, WaitTime).until(e->e.findElement(byElem));
		return new WebEssentials(driver);
	}
	
	/**
	 * @param element
	 */
	public void clickJSElement(WebElement element) {
		String jScript = "let clickButton =  (()=>{arguments[0].click();});clickButton()";
	    ((JavascriptExecutor)driver).executeScript(jScript,element);
	}
	
	/**
	 * @param oldStr
	 * @param reStr (Optional parameter)
	 * @return
	 */
	public String getTidyString(String oldStr, String... reStr) {
		if (reStr.length>0) {
			for(String st:reStr) {
				oldStr=oldStr.replaceAll(st, "");
			}
		}
		return oldStr.replaceAll("[^\\x00-\\x7F]", "")
				     .replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "")
				     .replace("\\p{C}", "")
				     .trim()
				     .toString();
	}

	public void waitForPageLoad(){
		String s="";
		while(!s.equals("complete")){
			JavascriptExecutor js = (JavascriptExecutor)driver;
			s=(String) js.executeScript("return document.readyState");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void scroll() {
		((JavascriptExecutor) driver).executeScript("scroll(0, 100);");
	}

	public boolean isAttribtuePresent(WebElement element, String attribute) {
		Boolean result = false;
		try {
			String value = element.getAttribute(attribute);
			if (value != null) {
				result = true;
			}
		} catch (Exception e) {

		}

		return result;
	}

	public WebEssentials openNewTabWithUrl(String strURL) {
		((JavascriptExecutor) driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		driver.get(strURL);

		return new WebEssentials(driver) ;
	}

	public WebEssentials closeCurrentWindow() throws Exception
	{
		driver.close();
		return new WebEssentials(driver);
	}

	public WebEssentials switchToMainWindow() {
		Set<String> openedWindows = driver.getWindowHandles();
		if (openedWindows.size() <= 1) //check if there is only one window open
		{
			for (String windowHandle : openedWindows) //had to use for for iterating through set, though it just contains one element.
			{
				driver.switchTo().window(windowHandle);
				break;
			}
		} else
			Assert.assertTrue(false, "there are multiple windows open, please close the same first");
		return new WebEssentials(driver);
	}

}