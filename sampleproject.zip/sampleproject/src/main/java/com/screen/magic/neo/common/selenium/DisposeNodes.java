package com.screen.magic.neo.common.selenium;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
public class DisposeNodes {
	    
    private static final int REMOTE_PORT = 22;
    private static final int SESSION_TIMEOUT = 10000;
    private static final int CHANNEL_TIMEOUT = 5000;
    private static final String USERNAME1_Node = ""; //TODO update username and password
    private static final String PASSWORD1_Node = "";	 	
	
    public static void cleanupNodes(String Nodes)  {
    	try {
	    	String REMOTE_HOST_NodeArr[]= Nodes.split("#");
			for(int i=0;i<REMOTE_HOST_NodeArr.length;i++) {
				disposeNodesOnRemoteMac(REMOTE_HOST_NodeArr[i], USERNAME1_Node, PASSWORD1_Node);
				Thread.sleep(70000);
			}
    	 } catch (Exception e) {
	            e.printStackTrace();
	     }
    }
	
	public static void disposeNodesOnRemoteMac(String Source_Mac_IP,String Source_UserName, String Source_Password) {
		String runRemoteShellScript = File.separator + "Users"+ File.separator +  Source_UserName + File.separator + "desktop"+File.separator + "SafariGridSetup"+ File.separator + "disposeGrid.sh";
		System.out.println("Started to dispose Grid on "+Source_Mac_IP);
		
		Session jschSession = null;
		
		try {
			
	            JSch jsch = new JSch();
	            jschSession = jsch.getSession(Source_UserName, Source_Mac_IP, REMOTE_PORT);
	            jschSession.setConfig("StrictHostKeyChecking", "no");
	            // authenticate using password
	            jschSession.setPassword(decodePassword(Source_Password));
	            // 10 seconds timeout session
	            jschSession.connect(SESSION_TIMEOUT);
	            ChannelExec channelExec = (ChannelExec) jschSession.openChannel("exec");

	            channelExec.setCommand("sh " + runRemoteShellScript);
	            
	            // display errors to System.err
	            channelExec.setErrStream(System.err);

	            InputStream in = channelExec.getInputStream();

	            // 5 seconds timeout channel
	            channelExec.connect(CHANNEL_TIMEOUT);

	            // read the result from remote server
	            byte[] tmp = new byte[1024];
	            while (true) {
	                while (in.available() > 0) {
	                    int i = in.read(tmp, 0, 1024);
	                    if (i < 0) break;
	                    System.out.print(new String(tmp, 0, i));
	                }
	                if (channelExec.isClosed()) {
	                    if (in.available() > 0) continue;
	                    System.out.println("exit-status: "  
	                         + channelExec.getExitStatus());
	                    break;
	                }
	                try {
	                    Thread.sleep(1000);
	                } catch (Exception ee) {
	                }
	            }

	            channelExec.disconnect();
	            System.out.println("Process completed on REMOTE_HOST is " + Source_Mac_IP);
	            System.out.println("--------------------------------------------------------");

	        } catch (JSchException | IOException e) {

	            e.printStackTrace();

	        } finally {
	            if (jschSession != null) {
	                jschSession.disconnect();
	            }
	        }

	    }
	
	public static String decodePassword(String encodedPwd) {
		byte[] decoded = Base64.getDecoder().decode(encodedPwd);
		return new String(decoded);
	}
}
	
