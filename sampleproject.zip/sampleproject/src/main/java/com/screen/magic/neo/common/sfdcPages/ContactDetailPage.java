package com.screen.magic.neo.common.sfdcPages;


import com.screen.magic.neo.common.customException.CustomException;

import com.screen.magic.neo.common.StartupPage;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ContactDetailPage extends StartupPage {

    @FindBy(xpath="//*[@class='menu-button-item slds-dropdown-trigger slds-dropdown-trigger_click']")
    public WebElement ddAllNewNotes;

    @FindBy(xpath="//*[@title='Follow']")
    public WebElement btnFollow;

    @FindBy(xpath="//a[@name='smagicinteract__Send_SMS']")
    public WebElement btnSendSMS;

    @FindBy(xpath="//*[text()='Consent not applicable']")
    public WebElement consentText;

    @FindBy(xpath="//a[@name='PrintableView']")
    public WebElement printableView;

    @FindBy(id="textField")
    public WebElement txtMessage;

    @FindBy(xpath="//*[@class='row-span consent-mode']/lightning-formatted-text[@class='text-label']")
    public WebElement lableConsent;

    @FindBy(xpath="//button[@class='slds-button slds-button_neutral slds-float_right']")
    public WebElement btnCancel;

    @FindBy(xpath="//div[@class='slds-form-element']//*[text()='Sender ID :']/parent::*/following-sibling::div/input")
    private WebElement autoPopulatedSenderId;

    @FindBy(xpath="//iframe[@title='accessibility title']")
    private WebElement iframe;

    public ContactDetailPage(WebDriver driver) {
        super(driver);
    }

    public ContactDetailPage clickOnDDNewNotes() throws Exception{
        try{

            webEssentials.waitTillElementIsClickable(btnFollow)
                    .waitTillElementIsClickable(ddAllNewNotes)
                    .moveToElementAndClick(ddAllNewNotes)
                    .waitTillAttributeContains(printableView,"name","PrintableView")
                    .waitTillElementIsClickable(btnSendSMS)
                    .moveToElementAndClick(btnSendSMS);

              new WebDriverWait(driver, 3000)
                  //    .ignoring(StaleElementReferenceException.class)
                 //     .ignoring(WebDriverException.class)
                         .until(ExpectedConditions.attributeContains(iframe,"title","accessibility title"));
              webEssentials.waitTillElementIsAvailableInDOM(By.xpath("//iframe"));
            webEssentials.waitTillAttributeContains(iframe,"title","accessibility title");
            webEssentials.waitTillElementIsVisible(iframe);
            webEssentials.waitTillFrameIsAvailableAndSwitch(iframe);
            webEssentials.waitTillInnerTextMatches(consentText,"Consent not applicable");
            webEssentials.waitTillAttributeContains(btnCancel,"type","button");
            webEssentials.waitTillElementIsVisible(btnCancel);
            webEssentials.waitTillElementIsClickable(btnCancel);


        }catch(Exception e){
            throw new CustomException(e, driver);
        }
        return initializeContactDetailPage();
    }


    public String verifyPhoneNumber() throws Exception{
        try{
        webEssentials.waitTillInnerTextMatches(lableConsent,"Consent Mode:");
            webEssentials.waitTillElementIsClickable(txtMessage);
            try{
                new WebDriverWait(driver, 300).ignoring(StaleElementReferenceException.class)
                        .ignoring(NoSuchElementException.class)
                        .until(ExpectedConditions.visibilityOf((driver.findElement(By.xpath("//td[@data-label='Mobile Phone']")))));

            }catch(Exception ex){

            }
            WebElement autoPopulatedPhoneField = webEssentials.findTheElement(By.xpath("//td[@data-label='Mobile Phone']"));
            webEssentials.waitTillElementIsVisible(autoPopulatedPhoneField);
            webEssentials.moveToElementAndClick(autoPopulatedPhoneField);
            String phoneFieldText = webEssentials.jsGetTextContent(autoPopulatedPhoneField);
            return phoneFieldText;
        }catch(Exception e){

            throw new CustomException(e, driver);
        }

    }
    public ContactDetailPage navigateURL(String URL) throws Exception {
        webEssentials.navigateTo(URL);

        return initializeContactDetailPage();
    }



    public String verifySenderId() throws Exception{
        try{
            String senderIdFieldText= webEssentials.getAttribute(autoPopulatedSenderId,"title");
            System.out.println(senderIdFieldText);
            return senderIdFieldText;
        }catch(Exception e){
            throw new CustomException(e, driver);
        }
    }


}
