package com.screen.magic.neo.common.restAssured;

import com.jayway.restassured.response.Response;

import java.util.Properties;

public class ApexQueryExecutor {
	
	RestAPIFundamentals fundamental;
	
	public String deleteDataURL = "/tooling/executeAnonymous/?anonymousBody=";
	public String insertDataURL = "/tooling/executeAnonymous/?anonymousBody=";
	public String selectDataURL="/query/?q=";
	
	public String version = "/services/data/v45.0";
	
	public ApexQueryExecutor(Properties prop) {
		fundamental = new RestAPIFundamentals(prop);
		String instanceURL = fundamental.getInstanceURL();
		String baseURL = instanceURL+version;
		this.deleteDataURL = baseURL+this.deleteDataURL;
		this.insertDataURL = baseURL+this.insertDataURL;
		this.selectDataURL = baseURL+this.selectDataURL;
	}
	
	public Response deleteData(String queriesList) {
		return fundamental.getData(deleteDataURL+queriesList);
    }
   
    public Response insertData(String queriesList) {
    	return fundamental.getData(insertDataURL+queriesList);
    }
   
    public Response selectData(String queriesList) {
    	return fundamental.getData(selectDataURL+queriesList);
    }
    

}
