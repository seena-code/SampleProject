package com.screen.magic.neo.common;

public class CommonTestData {
    public final static String homePageTitle = "Home | Salesforce";
}
