package com.screen.magic;

import com.google.common.base.MoreObjects;
import com.jayway.restassured.response.Response;
import com.screen.magic.neo.common.apis.utils.RestValidation;
import com.screen.magic.neo.common.customException.CustomExceptionPOJO;
import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import com.screen.magic.neo.common.*;
import com.screen.magic.neo.common.customException.CustomException;
import com.screen.magic.neo.common.apis.SFDCHelper;
import com.screen.magic.neo.common.apis.utils.SFDCRestUtils;
import com.screen.magic.neo.common.helpers.Efficacies;
import com.screen.magic.neo.common.helpers.JavaHelpers;
import com.screen.magic.neo.common.selenium.WebDriverUtils;
import com.screen.magic.neo.common.sfdcPages.ContactDetailPage;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import java.util.*;
import static org.testng.Assert.assertTrue;

public class StepDefinition {
    public static List<CustomExceptionPOJO> errorClassified = new ArrayList<>();
    public WebDriver driver;
    public Efficacies efficacies;
    public StartupPage startUpPage;
    public GenericPage genericPage;
    public Properties environmentProperties;
    public LoginPage loginPage;
    public HomePage homePage;
    public String browser;
    public String hubURL;
    public JavaHelpers javaHelpers;
    public SFDCRestUtils sfdcRestUtils;
    public SFDCHelper sfdcHelper;
    String instanceURL;
    public ContactDetailPage contactDetailPage;
    public String scenarioName;
    Response response;

    @BeforeClass(alwaysRun = true)
    @Given("^salesforce login is completed using the configuration from (.*?)$")
    public void salesforce_Login_isCompleted(String environmentFileName) throws Exception {
        try {
            javaHelpers = new JavaHelpers();
            environmentProperties = javaHelpers.loadPropertyFile(environmentFileName);
            this.browser = environmentProperties.getProperty("browser");
            this.browser = environmentProperties.getProperty("hubURL");
            WebDriverUtils utils = new WebDriverUtils();
            utils.initializeDriver(browser, hubURL);
            driver = utils.getDriver();
            efficacies = new Efficacies();
            startUpPage = new StartupPage(driver);
            contactDetailPage = startUpPage.initializeContactDetailPage();
            genericPage = startUpPage.initializeGenericPage();
            Map<String, String> testData = new HashMap<String, String>();
            testData.put("url", environmentProperties.getProperty("SFURL"));
            testData.put("username", environmentProperties.getProperty("userName"));
            testData.put("password", environmentProperties.getProperty("password"));
            testData.put("client_id", environmentProperties.getProperty("clientid"));
            testData.put("client_secret", environmentProperties.getProperty("clientsecret"));
            loginPage = startUpPage.navigateToLoginPage(environmentProperties.getProperty("sfloginURL"));
            homePage = loginPage.waitForLoginPageLoad().loginToApp(testData.get("username"), testData.get("password"));
            //api access token code
            sfdcRestUtils = new SFDCRestUtils();
            instanceURL = sfdcRestUtils.generateSFDCAccessToken(testData);
            sfdcHelper = new SFDCHelper(instanceURL, sfdcRestUtils);

        } catch (Exception e) {
            throw new CustomException(e, driver, scenarioName);
        }
    }

    @Then("switch the view to lightening")
    public void salesforce_SwitchView() throws Exception {
        try {
            Boolean flag = genericPage.checkURL("lightening");
            if (flag == false) {
                homePage.switchToLightning();
            }
        } catch (Exception e) {
            throw new CustomException(e, driver);
        }
    }

    @Then("^navigate to contact with \"([^\"]*)\" from file \"([^\"]*)\" under element \"([^\"]*)\"$")
    public void navigateToContactWithId(String contactId, String fileName, String node) throws Exception {
        try {
            Map<String, String> testDataMap = new HashMap<String, String>();
            testDataMap = efficacies.readJsonElement(fileName, node);
            contactId = testDataMap.get(contactId);
            String newURL = instanceURL + "/" + contactId;
            contactDetailPage.navigateURL(newURL);
        } catch (Exception e) {
            throw new CustomException(e, driver);
        }
    }

    @When("^clicked on SingleSMS under NewNote$")
    public void clickedOnSingleSMSUnderNewNote() throws Exception {
        contactDetailPage.clickOnDDNewNotes();
    }

    @Then("^assert the autopopulated mobile number is \"([^\"]*)\" from file \"([^\"]*)\" under element \"([^\"]*)\"$")
    public void assertTheAutopopulatedMobileNumberIs(String mobileNum, String fileName, String node) throws Exception {
        try {
            Map<String, String> testDataMap = new HashMap<String, String>();
            testDataMap = efficacies.readJsonElement(fileName, node);
            mobileNum = testDataMap.get(mobileNum);
            assertTrue(contactDetailPage.verifyPhoneNumber().equals(mobileNum));

        } catch (Exception e) {
            throw new CustomException(e, driver);
        }
    }

    @Then("^assert the autopopulated sender id is \"([^\"]*)\" from file \"([^\"]*)\" under element \"([^\"]*)\"$")
    public void assertTheAutopopulatedSenderIdIs(String senderId, String fileName, String node) throws Exception {
        try {
            Map<String, String> testDataMap = new HashMap<String, String>();
            testDataMap = efficacies.readJsonElement(fileName, node);
            senderId = testDataMap.get(senderId);
            assertTrue(contactDetailPage.verifySenderId().contains(senderId));
        } catch (Exception e) {
            throw new CustomException(e, driver);
        }
    }

    @Given("^salesforce oauth token is generated using the configuration from \"([^\"]*)\"$")
    public void salesforceOauthTokenIsGeneratedUsingTheConfigurationFrom(String environmentFileName) throws Throwable {
        javaHelpers = new JavaHelpers();
        environmentProperties = javaHelpers.loadPropertyFile(environmentFileName);
        Map<String, String> testData = new HashMap<String, String>();
        testData.put("url", environmentProperties.getProperty("SFURL"));
        testData.put("username", environmentProperties.getProperty("userName"));
        testData.put("password", environmentProperties.getProperty("password"));
        testData.put("client_id", environmentProperties.getProperty("clientid"));
        testData.put("client_secret", environmentProperties.getProperty("clientsecret"));

        sfdcRestUtils = new SFDCRestUtils();
        instanceURL = sfdcRestUtils.generateSFDCAccessToken(testData);
        sfdcHelper = new SFDCHelper(instanceURL, sfdcRestUtils, true);
    }

    @And("^construct the request body from file \"([^\"]*)\" under element \"([^\"]*)\"$")
    public void constructTheRequestBodyFromFileUnderElement(String fileName, String node) throws Throwable {
        Map<String, String> testDataMap = new HashMap<String, String>();
        testDataMap = new Efficacies().readJsonElement(fileName, node);
        response = sfdcHelper.changeCustomSettings(testDataMap);
    }

    @Then("^Assert the response contains value as follows$")
    public void assertTheResponseContainsValueAsFollows(DataTable table) {
        Map<String, String> expectedResponseMap = table.asMap(String.class, String.class);
        Map<String, String> actualResponseMap = response.as(HashMap.class);
        System.out.println(response.as(HashMap.class));
        Set<Map.Entry<String, String>> entrySet = expectedResponseMap.entrySet();
        for (Map.Entry<String, String> entry : entrySet) {
            Assert.assertTrue(new RestValidation().exists(actualResponseMap,
                    entry.getKey(), entry.getValue()));
        }
    }

    @After
    public void tearDownafter() {

        if (driver == null) {
            System.out.println("This is an API call");
        } else {
            startUpPage.killDriver();
        }
    }

    @AfterClass(alwaysRun=true)
    public void tearDown()
    {
        startUpPage.killDriver();
    }
}
