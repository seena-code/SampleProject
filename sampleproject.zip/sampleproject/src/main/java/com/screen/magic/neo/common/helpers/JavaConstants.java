package com.screen.magic.neo.common.helpers;

public class JavaConstants {
	
	public static String HTTPOK = "200";
	public static String HTTPCREATED = "200";

}
