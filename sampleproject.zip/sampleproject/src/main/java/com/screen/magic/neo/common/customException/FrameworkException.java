package com.screen.magic.neo.common.customException;

public class FrameworkException extends Exception {

	public FrameworkException(String message) {
		super(message);
	}
	
	public FrameworkException() {
		super();
	}
}
