package com.screen.magic.neo.common;

import com.screen.magic.neo.common.fundamentals.WebEssentials;
import com.screen.magic.neo.common.sfdcPages.ContactDetailPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class StartupPage {
   public WebDriver driver;
   public WebEssentials webEssentials;

   public StartupPage(WebDriver driver){
      this.driver = driver;
      webEssentials = new WebEssentials(driver);
      webEssentials.setWaitTime(90);
   }

   public LoginPage navigateToLoginPage(String baseURL) {
      try {
         webEssentials.maximizeWindow().navigateTo(baseURL);
      } catch (Exception e) {
      }
      return initializeLoginPage();
   }

   public LoginPage initializeLoginPage() {
      return PageFactory.initElements(driver, LoginPage.class);
   }

   public GenericPage initializeGenericPage() {
      return PageFactory.initElements(driver, GenericPage.class);
   }

   public HomePage initializeHomePageLightning() {
      return PageFactory.initElements(driver, HomePage.class);
   }

   public ContactDetailPage initializeContactDetailPage() {
      return PageFactory.initElements(driver, ContactDetailPage.class);
   }

   public void killDriver() {
      try {
         driver.quit();
      } catch (Exception e) {
      }
   }


}
