package com.screen.magic.neo.common.restAssured;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

import java.util.Properties;

public class RestAPIFundamentals {
	
	private String accessToken;
	private String instanceURL;

	public String getInstanceURL() {
		return instanceURL;
	}

	public void setInstanceURL(String instanceURL) {
		this.instanceURL = instanceURL;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
	public RestAPIFundamentals(Properties credentials) {
		generateSFDCAccessToken(credentials);
	}

	public String getAccessToken() {
		return this.accessToken;
	}
	
	/**
	 * 
	 * @param testData Provide the valid properties as follows: client_id,
	 * client_secret,username,password,url
	 * @return Instance URL for the SFDC
	 */
	public String generateSFDCAccessToken(Properties credentials) {
		Response response = RestAssured.given()
								.formParam("grant_type", "password")
								.formParam("client_id", credentials.get("client_id"))
								.formParam("client_secret", credentials.get("client_secret"))
								.formParam("username", credentials.get("username"))
								.formParam("password", credentials.get("password"))
								.post(credentials.get("url").toString());
		JsonPath path = new JsonPath(response.getBody().asString());
		this.accessToken = path.get("access_token");
		this.setAccessToken(accessToken);
		String instanceURL = path.get("instance_url");
		this.setInstanceURL(instanceURL);
		return instanceURL;
	}
	
	/**
	 * Fetches the data
	 * @param url Provide the APIURI
	 * @param queryParams Provide the SQL Query
	 * @return response
	 */
	public Response getData(String url) {
		return RestAssured.given()
							.header("Authorization", "Bearer " + accessToken)
							.header("Content-Type", "application/json")
							.get(url);
	}
	
	/**
	 * Fetches the data
	 * @param url Provide the APIURI
	 * @param queryParams Provide the SQL Query
	 * @return response
	 */
	public Response getWithQueryParams(String url, String queryParams) {
		return RestAssured.given()
							.header("Authorization", "Bearer " + accessToken)
							.header("Content-Type", "application/json")
							.queryParam("q",queryParams)
							.get(url);
	}

	/**
	 * Creates the data with payload
	 * @param url Provide the APIURI
	 * @param body Provide the Request Body
	 * @return response
	 */
	public Response postWithoutAppUrl(String url, String body) {
		return RestAssured.given()
							.header("Authorization", "Bearer " + accessToken)
							.header("Content-Type", "application/json")
							.body(body)
							.post(url);
	}
	
	/**
	 * Updates the data with payload
	 * @param url Provide the APIURI
	 * @param body Provide the Request Body
	 * @return response
	 */
	public Response patchWithoutAppUrl(String url, String body) {
		return RestAssured.given()
							.header("Authorization", "Bearer " + accessToken)
							.header("Content-Type", "application/json")
							.body(body)
							.patch(url);
	}
	
	/**
	 * Deletes the data without payload
	 * @param url Provide the APIURI
	 * @return response
	 */
	public Response deleteWithoutPayload(String url) {
		return RestAssured.given()
							.header("Authorization", "Bearer " + accessToken)
							.header("Content-Type", "application/json")
							.delete(url);
	}

}
