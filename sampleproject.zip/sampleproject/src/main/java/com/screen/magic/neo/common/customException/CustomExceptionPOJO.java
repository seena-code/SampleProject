package com.screen.magic.neo.common.customException;


public class CustomExceptionPOJO {
    private String testName;
    private String exceptionTrace;
    private String exception;
    private String issueType;
    public String getIssueType() {
        return issueType;
    }
    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }
    public String getTestName() {
        return testName;
    }
    public void setTestName(String testName) {
        this.testName = testName;
    }
    public String getExceptionTrace() {
        return exceptionTrace;
    }
    public void setExceptionTrace(String exceptionTrace) {
        this.exceptionTrace = exceptionTrace;
    }
    public String getException() {
        return exception;
    }
    public void setException(String exception) {
        this.exception = exception;
    }


}
