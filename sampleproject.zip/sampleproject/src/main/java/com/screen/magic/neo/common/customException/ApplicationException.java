package com.screen.magic.neo.common.customException;

public class ApplicationException extends Exception {

	public ApplicationException(String message) {

		super(message);
	}
	
}
