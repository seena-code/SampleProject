package com.screen.magic.neo.common.apis;


import com.screen.magic.neo.common.helpers.Efficacies;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


    public class GeneralHelper {
        static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        static Date date = new Date();
        static String DateFormat="MM/dd/yyyy";
        public static String DateFormatMdd="M/dd/yyyy";
        public static String DateFormatMd = "M/d/yyyy";
        static String DateFormatMMd="MM/d/yyyy";
        public static String DateFormatyyyymm="yyyy-MM-dd";
        public static String dateFormatWithTime = "yyyy-MM-dd 00:00:00";
        public String dateFormatWithMonthName = "MMMM d, yyyy";

        public String resourcePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main"
                + File.separator + "resources" + File.separator + "clm" + File.separator;

        public String fileUploadPath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main"
                + File.separator + "resources" + File.separator + "FilesToUpload" + File.separator;

        public static String getCurrentDate() {
            return dateFormat.format(new Date()) + "T00:00:00.000";
        }

        public static String getFutureDate(int daysInFuture) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DATE, +daysInFuture);
            return dateFormat.format(calendar.getTime())+"T00:00:00.000";
        }

        public static String getPastDate(String dateFormat, int dayInPast) {
            DateFormat format = new SimpleDateFormat(dateFormat);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.DATE, -dayInPast);
            return format.format(cal.getTime());
        }

        public static String getOnlyCurrentDate(String dateFormat) {
            DateFormat format = new SimpleDateFormat(dateFormat);
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE,0);
            return format.format(calendar.getTime());
        }

        public static String getFutureDateOnly(int dayInFuture,String dateFormat) {
            DateFormat format = new SimpleDateFormat(dateFormat);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.DATE, +dayInFuture);
            return format.format(cal.getTime());
        }

        public static String getFutureDate(String strDate,int daysInFuture) throws ParseException {
            SimpleDateFormat dateFormat = new SimpleDateFormat(DateFormatMd);
            Date newDate = dateFormat.parse(strDate);
            return dateFormat.format(DateUtils.addDays(newDate, daysInFuture));
        }

        public static String formatDate(String strDate) throws ParseException {
            SimpleDateFormat dateFormatMd = new SimpleDateFormat(DateFormatMd);
            SimpleDateFormat dateFormatMdd = new SimpleDateFormat(DateFormatMdd);
            SimpleDateFormat dateFormatMMd = new SimpleDateFormat(DateFormatMdd);
            SimpleDateFormat dateFormat = new SimpleDateFormat(DateFormat);

            Date newDate = dateFormat.parse(strDate);
            String str=((strDate.startsWith("0"))||(strDate.substring(3).contains("0"))?((strDate.startsWith("0"))&&
                    (strDate.substring(3).contains("0"))?dateFormatMd.format(newDate):strDate):(((strDate.startsWith("0"))
                    ?dateFormatMdd.format(newDate):(strDate.substring(3).contains("0"))?dateFormatMMd.format(newDate):strDate)));

            return str;
        }

        public static String returnTodaysDate(String dateFormat) {
            SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
            Date date = new Date();
            return formatter.format(date);
        }

        public static String returnFutureDate(String dateFormat, int days) {
            SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
            Calendar c = Calendar.getInstance();
            c.add(5, days);
            return formatter.format(c.getTime());
        }

        public static String formatDate() {
            String str = returnTodaysDate("MM").startsWith("0") ? returnTodaysDate("M/d/yyyy")
                    : returnTodaysDate("MM/d/yyyy");
            return str;
        }

        public static String formatDate(int days) {
            String str = returnFutureDate("MM",days).startsWith("0") ? returnFutureDate("M/d/yyyy",days)
                    : returnFutureDate("MM/d/yyyy",days);
            return str;
        }

        public static String formatPastDate(int days) {
            String str = getPastDate("MM", days).startsWith("0") ? getPastDate("M/d/yyyy", days)
                    : getPastDate("MM/d/yyyy", days);
            return str;
        }

        /**
         * Convert String date to Specific Date format
         * @param  strDate, String dateFormat, String newDateFormat
         * @return String Date
         * @throws Exception
         */
        public String convertDateFormat(String strDate, String dateFormat, String newDateFormat) throws Exception {
            //Parse String to Date
            DateFormat format = new SimpleDateFormat(dateFormat);
            Date date = format.parse(strDate);

            //Convert Date to Specific Date format
            SimpleDateFormat formatTwo = new SimpleDateFormat(newDateFormat);
            String dates = formatTwo.format(date);
            return dates;
        }

        /**
         * Convert String date to Specific Date format
         * @return String Date
         * @throws Exception
         */
        public String convertAgrDateFormat(String strDate) throws Exception {
            String newFormat = null;
            if((strDate.charAt(5)=='0') && (strDate.charAt(8)=='0')) {
                newFormat = DateFormatMd;
            } else if((strDate.charAt(5)!='0') && (strDate.charAt(8)!='0')) {
                newFormat = DateFormat;
            } else if((strDate.charAt(5)!='0') && (strDate.charAt(8)=='0')) {
                newFormat = DateFormatMMd;
            } else if((strDate.charAt(5)=='0') && (strDate.charAt(8)!='0')) {
                newFormat = DateFormatMdd;
            }

            return convertDateFormat(strDate.split("T")[0], DateFormatyyyymm, newFormat);
        }

        /**
         * Convert String date to Specific Date format
         * @return String Date
         * @throws Exception
         */
        public String convertDateFormat(String strDate) throws Exception {
            String newFormat = null;
            if((strDate.charAt(5)=='0') && (strDate.charAt(8)=='0')) {
                newFormat = DateFormatMd;
            } else if((strDate.charAt(5)!='0') && (strDate.charAt(8)!='0')) {
                newFormat = DateFormat;
            } else if((strDate.charAt(5)!='0') && (strDate.charAt(8)=='0')) {
                newFormat = DateFormatMMd;
            } else if((strDate.charAt(5)=='0') && (strDate.charAt(8)!='0')) {
                newFormat = DateFormatMdd;
            }

            return convertDateFormat(strDate, DateFormatyyyymm, newFormat);
        }

        /**
         * Convert File data to String
         * @param filePath
         * @return
         * @throws IOException
         */
        public String getContentFromFile(String filePath) throws IOException {
            String content = new String(Files.readAllBytes(Paths.get(filePath)));
            return content;
        }

        /**
         * Get the jsonobject from json file.
         * @param filePath
         * @param name
         * @return
         * @throws Exception
         */
        public Object getJsonNodeFromJsonFile(String filePath, String name) throws Exception {
            Object obj = new JSONParser().parse(new FileReader(filePath));
            JSONObject jo = (JSONObject) obj;
            return jo.get(name);
        }

        /**
         * This method will increment the value depends on minor and major type. If
         * Minor then it will increment the value from 1.0.0 to 1.1.0 else Major then
         * will increment the value from 1.0.0 to 2.0.0.
         *
         * @param givenStr
         * @param type
         *
         * @return
         */
        public String getIncrVersion(String givenStr, String type) {
            StringBuilder resultStr = new StringBuilder();
            String[] strArr = givenStr.split("\\.");
            if(type.toLowerCase().equals("minor"))
                strArr[1] = String.valueOf(Integer.parseInt(strArr[1]) + 1);
            else if(type.toLowerCase().equals("major"))
                strArr[0] = String.valueOf(Integer.parseInt(strArr[0]) + 1);
            for (String str : strArr) {
                resultStr.append(str).append(".");
            }
            return resultStr.substring(0, resultStr.length() - 1);
        }

        /**
         * Get the correct version when trim is true/false cases.
         * @param givenVersion
         * @param isVersionTrim
         * @return
         */
        public String getDocVersion(String givenVersion, String isVersionTrim) {
            return isVersionTrim.equals("false") ? givenVersion : givenVersion.substring(0, 3);
        }

        /**
         * This method will split the given string with multiple values with given delimiter and retruns the sorted set.
         * @param givenString
         * @param delimiter
         * @return
         */
        public Set<String> getSortedSet(String givenString, String delimiter) {
            Set<String> resultSet = new TreeSet<String>();
            for (String val : givenString.split(delimiter)) {
                resultSet.add(val.trim());
            }
            return resultSet;
        }



        /*
         * To generate 5 digit Random Number.
         */
        public String generateFiveDigitNumber(){
            Random random=new Random();
            return Integer.toString(random.nextInt(100000));
        }

        public JSONObject getObjFromJsonArrayStr(String givenStr) throws Exception {
            JSONArray jsonArr =  (JSONArray) new JSONParser().parse(givenStr);
            return (JSONObject)jsonArr.get(0);
        }

        public List<String> removeDuplicateFromList(List<String> givenList){
            Set<String> set = new LinkedHashSet<>();
            set.addAll(givenList);
            givenList.clear();
            givenList.addAll(set);
            return givenList;
        }

        /**
         * This method is used to copy the file from given file
         * @param fileName
         * @param reqExtension
         * @return
         */
        public String copyFiles(String fileName, String reqExtension) {
            String newFileName = "Sample_" + new Efficacies().generateRandomNumber() + reqExtension;
            try {
                String original = fileUploadPath + fileName;
                File copiedFile = new File(fileUploadPath + newFileName);
                FileUtils.copyFile(new File(original), copiedFile);
            } catch (IOException e) {
            }
            return newFileName;
        }
    }


