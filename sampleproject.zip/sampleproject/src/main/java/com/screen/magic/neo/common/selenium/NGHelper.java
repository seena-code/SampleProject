package com.screen.magic.neo.common.selenium;

import com.github.javafaker.Faker;
import com.paulhammant.ngwebdriver.ByAngular;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.screen.magic.neo.common.fundamentals.WebEssentials;
import com.screen.magic.neo.common.helpers.JavaHelpers;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;



public class NGHelper {
	
	public WebDriver driver;
	public NgWebDriver ngdriver;
	public static boolean cookie = false;
	
	public static Integer scriptTimeOut=0;

	private String toggleCheck = "input[aria-label='<<LABEL>>'].toggle:checked";
	private String toggleControl = "input[aria-label='<<LABEL>>']";

	
	/**
	 * @param driver
	 */
	public NGHelper(WebDriver driver) {
		this.driver = driver;
		if (scriptTimeOut==0){
			driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		}
		if (scriptTimeOut==180) {
			driver.manage().timeouts().setScriptTimeout(scriptTimeOut, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		}
	}
	
	/**
	 * 
	 */
	public void clmScriptTimeOut() {
		setScriptTimeOut(180);
	}

	
	/**
	 * @return
	 */
	public static Integer getScriptTimeOut() {
		return scriptTimeOut;
	}

	/**
	 * @param scriptTimeOut
	 */
	public static void setScriptTimeOut(Integer scriptTimeOut) {
		NGHelper.scriptTimeOut = scriptTimeOut;
	}
	
    
	/**
	 * Method to generate random number.
	 * 
	 * @return Random number string.
	 * @throws Exception
	 */
	public String genRandomNumber() throws Exception{
		return Long.toString(JavaHelpers.generateRandomNumber());
	}


	/**
	 * Method to Create a paragraph of required lines 
	 * 
	 * @param lines
	 *        which should be an Integer
	 * @return Paragraph of specified lines as String
	 * @throws Exception
	 */
	public String genParagraph(int lines) throws Exception{
		return new Faker(new Locale("en")).lorem().paragraph(lines);
	}

	
	
	/**
	 * Method to Generate Date with specified format
	 * 
	 * @param format
	 *        Which should be in this format "dd/MM/YYYY", "DD/YYYY/MM" or "mm/DD/YYYY" etc
	 * @param daysDifference
	 *        Which represent the date interval from the Current Date
	 * @return Date in the form of String with the required format and interval
	 * @throws Exception 
	 */
	public String genDate(String format, int daysDifference) throws Exception{
		SimpleDateFormat simpledate = new SimpleDateFormat(format);
		return simpledate.format(new Faker().date().future(daysDifference, TimeUnit.DAYS));
	}
	
	
	
	/**
	 * Method to get List of elements matching the specified locator
	 *  
	 * @param byelem  
	 *        Which should be a valid locator for e.g. By.xpath("//tr//td"), By cssSelector("tr&#62;td"),
	 *                                                 By.id("validID"), By.Name("Valid Name") etc.
	 * @return List of Web Elements matching the Locator
	 */
	public List<WebElement> findTheElements(By byelem){
		return driver.findElements(byelem);
	}
	
	
	
	/**
	 * Method to Enable/Disable toggle button
	 * 
	 * @param toggleLabel
	 *        Which should be a label of the toggle button
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper toggleAction(String toggleLabel) throws Exception {
		try {
			WebElement elem = driver
					.findElement(By.cssSelector(toggleCheck.replace("<<LABEL>>", toggleLabel).toString()));
			elem = driver.findElement(By.cssSelector(toggleControl.replace("<<LABEL>>", toggleLabel).toString()));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", elem);
			return new NGHelper(driver);
		} catch (Exception ex) {
			WebElement elem = driver
					.findElement(By.cssSelector(toggleControl.replace("<<LABEL>>", toggleLabel).toString()));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", elem);
			return new NGHelper(driver);
		}
	}

	/**
	 * Method to perform click action using java script
	 * Note: This method should be used only if the click is not performing any action
	 * 
	 * @param elem 
	 *        Which should be a WebElement created using @FindBy annotations
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper jsClick(WebElement elem) throws Exception{
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", elem);
		return new NGHelper(driver);
	}

	

	/**
	 * Method to perform click action on specified web element
	 * 
	 * @param elem 
	 *        Which should be a WebElement created using @FindBy annotations
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper click(WebElement elem) throws Exception {
		waitForNGToLoad();
		if(((RemoteWebDriver)driver).getCapabilities().getBrowserName().equalsIgnoreCase("safari")) {
			jsClick(elem);
			waitForNGToLoad();
			return new NGHelper(driver);
		}
		elem.click();
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	/**
	 * Method to Send Keys (only Strings) to a Text Field.
	 * 
	 * @param elem
	 *        Which should be a WebElement created using @FindBy annotations
	 * @param str
	 *        Which should be a String to be sent to the specified WebElement
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper sendKeysTo(WebElement elem, String str) throws Exception {
		waitForNGToLoad();
		elem.sendKeys(str);
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	

	/**
	 * Method to Navigate to specified URL
	 * 
	 * @param url
	 *        Which should be a String 
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper NavigateTo(String url) throws Exception {
		waitForNGToLoad();
		driver.get(url);
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	

	/**
	 * Method to wait for the specified no of seconds
	 * 
	 * @param timeval
	 *        which should be a Double value e.g. 2.5,2,3.5 etc
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper sleepWait(double timeval) throws Exception{
		waitForNGToLoad();
		Double d = timeval * 1000;
		Integer intTime = d.intValue();
		Thread.sleep(intTime);
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	
    
	/**
	 * Method to wait till the specified WebElement is Clickable
	 * 
	 * @param elem 
	 *        Which should be a WebElement created using @FindBy Annotations
	 * @param timeval 
	 *        Which should be a integer value
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitTillElementIsClickable(WebElement elem, int timeval) throws Exception{
		waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.elementToBeClickable(elem)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	

	/**
	 * Method to wait till the specified WebElement is Visisble
	 * 
	 * @param elem 
	 *        Which should be a WebElement created using @FindBy Annotations
	 * @param timeval 
	 *        Which should be a integer value
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitTillElementIsVisible(WebElement elem, int timeval) throws Exception {
		waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(elem)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	
	/**
	 * Method to wait till the specified WebElement has the specified attribute and 
	 * attribute value
	 * 
	 * @param element
	 *        Which should be a WebElement created using @FindBy annotation
	 * @param attributeType
	 *        Which should be a String of attribute type for the specified WebElement
	 * @param attributeValue
	 *        Which should be a String of attribute value for the specified WebElement
	 * @param timeval
	 *        Which should be a integer value
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitTillAttributeValue(WebElement element,String attributeType,String attributeValue,int timeval) throws Exception {
		waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.attributeContains(element, attributeType, attributeValue)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
	}

	
	
	
	/**
	 * Method to wait till the progress bar reaches from 0 to 100%
	 * 
	 * @param elem
	 *        Which should be a WebElement created using @FindBy annotation
	 * @param waitTime
	 *        Which should be an integer (wait time till progress bar appears)
	 * @param endTime
	 *        Which should be an integer (wait time till progress bar reaches 100%)
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitTillProgressBarIsFull(WebElement elem, double waitTime, int endTime) throws Exception {
		try {
			ExecutionTimer.startTimer();
			WebDriverWait wait = new WebDriverWait(driver, endTime);
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			sleepWait(waitTime);
			if (elem.isDisplayed() == true) {
				sleepWait(waitTime);
				wait.until(ExpectedConditions.or(ExpectedConditions.invisibilityOf(elem)));
				waitForNGToLoad();
			}
			ExecutionTimer.endTimer();
			return new NGHelper(driver);
		} catch (Exception e) {
			ExecutionTimer.endTimer();
			return new NGHelper(driver);
		}
	}

	
	
	/**
	 * Method to wait till the specified WebElement is Invisisble
	 * 
	 * @param elem 
	 *        Which should be a WebElement created using @FindBy Annotations
	 * @param timeval 
	 *        Which should be a integer value
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitTillElementIsInvisible(WebElement elem, int timeval) throws Exception{
		waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.invisibilityOf(elem)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
	}

	
	/**
	 * Method to wait till the angular js Page loads completely
	 * 
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitForNGToLoad() throws Exception {
		ExecutionTimer.startTimer();
		ngdriver = new NgWebDriver((JavascriptExecutor) driver);
		ngdriver.waitForAngularRequestsToFinish();
		ExecutionTimer.endTimer();
		return new NGHelper(driver);
	}

	
	/**
	 * Method to click a button which has specified text
	 * 
	 * @param buttonText 
	 *        Which should be a String (Text on the button)
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper ngClickButtonWithText(String buttonText) throws Exception {
		waitForNGToLoad();
		jsClick(driver.findElement(ByAngular.buttonText(buttonText)));
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	
	/**
	 * Method to click a button which has specified partial text
	 * 
	 * @param partialButtonText 
	 *        Which should be a String (Partial text on the button)
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper ngClickButtonWithPartialText(String partialButtonText) throws Exception {
		waitForNGToLoad();
		jsClick(driver.findElement(ByAngular.partialButtonText(partialButtonText)));
		waitForNGToLoad();
		return new NGHelper(driver);
	}

	
	/**
	 * Method to get a WebElement matching the specifed ng-model attribute
	 * 
	 * @param model
	 *        Which should be a String and ng-model attribute value
	 * @return WebElement matching the specified ng-model
	 * @throws Exception
	 */
	public WebElement ngElementByModel(String model) throws Exception {
		waitForNGToLoad();
		return driver.findElement(ByAngular.model(model));
	}

	
	/**
	 * Method to get a WebElement matching the specifed ng-binding attribute
	 * 
	 * @param binding
	 *        Which should be a String and ng-binding attribute value
	 * @return WebElement matching the specified ng-binding
	 * @throws Exception
	 */
	public WebElement ngElementByBinding(String binding) throws Exception {
		waitForNGToLoad();
		return driver.findElement(ByAngular.binding(binding));
	}
	

	
	/**
	 * Method to get a WebElement matching the specified cssSelector and
	 * Text of the specified tag
	 * 
	 * @param cssSelector
	 *        Which should be string of valid cssSelector
	 * @param innerText
	 *        Which should a String
	 * @return webElement matching the specified parameters
	 * @throws Exception
	 */
	public WebElement ngCssContainingText(String cssSelector, String innerText) throws Exception {
		waitForNGToLoad();
		return driver.findElement(ByAngular.cssContainingText(cssSelector, innerText));
	}

	
	/**
	 * Method to get a WebElement matching the specifed ng-repeat attribute
	 * 
	 * @param repeater
	 *        Which should be a String and ng-repeat attribute value
	 * @return WebElement matching the specified ng-repeat
	 * @throws Exception
	 */
	public WebElement ngElementByRepeater(String repeater) throws Exception {
		waitForNGToLoad();
		return driver.findElement(ByAngular.exactRepeater(repeater));
	}
	
	

	/**
	 * Method to get List of WebElements matching the specifed ng-repeat attribute
	 * 
	 * @param repeater
	 *        Which should be a String and ng-repeat attribute value
	 * @return List of matching WebElemnts matching the specified ng-repeat
	 * @throws Exception
	 */
	public List<WebElement> ngGetAllRepeaterList(String repeater) throws Exception {
		waitForNGToLoad();
		return driver.findElements(ByAngular.exactRepeater(repeater));
	}

	
	
	/**
	 * Method to perform Drag and Drop 
	 * 
	 * @param source
	 *        Which should be a WebElement created using @FindBy annotation
	 * @param destination
	 *        Which should be a WebElement created using @FindBy annotation
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper DragAndDropJS(WebElement source, WebElement destination) throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("function createEvent(typeOfEvent) " + "{\n" 
		                + "var event =document.createEvent(\"CustomEvent\");\n"
						+ "event.initCustomEvent(typeOfEvent,true, true, null);\n" + "event.dataTransfer = {\n"
						+ "data: {},\n" + "setData: function (key, value) {\n" + "this.data[key] = value;\n" + "},\n"
						+ "getData: function (key) {\n" + "return this.data[key];\n" + "}\n" + "};\n"
						+ "return event;\n" + "}\n" + "\n" + "function dispatchEvent(element, event,transferData) "
						+ "{\n" + "if (transferData !== undefined) " + "{\n" + "event.dataTransfer = transferData;\n"
						+ "}\n" + "if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n" + "} "
						+ "else if (element.fireEvent) {\n" + "element.fireEvent(\"on\" + event.type, event);\n" + "}\n"
						+ "}\n" + "\n" + "function simulateHTML5DragAndDrop(element, destination) {\n"
						+ "var dragStartEvent =createEvent('dragstart');\n"
						+ "dispatchEvent(element, dragStartEvent);\n" + "var dropEvent = createEvent('drop');\n"
						+ "dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n"
						+ "var dragEndEvent = createEvent('dragend');\n"
						+ "dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" + "}\n" + "\n"
						+ "var source = arguments[0];\n" + "var destination = arguments[1];\n"
						+ "simulateHTML5DragAndDrop(source,destination);",source, destination);
		sleepWait(1);
		return new NGHelper(driver);
	}

	
	
	/**
	 * Method to Perform scroll and click action on the specified WebElement
	 * 
	 * @param elem
	 *        Which should be a WebElement created using @FindBy annotation
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper jScriptScrollAndClick(WebElement elem) throws Exception {
		waitForNGToLoad();
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elem);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", elem);
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	

	
	/**
	 * Method to Perform filter on the table column
	 * 
	 * @param tableElement
	 *        Which should be a WebElement created using @FindBy annotation
	 * @param textlabel
	 *        Which should be a String label present in the header of the table
	 * @param inputtext
	 *        Which should be a String 
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper sendKeysToTextBoxInTable(WebElement tableElement, String textlabel, String inputtext, String... charactersTobeRemoved)
			throws Exception {
		waitForNGToLoad();
		List<WebElement> headers = tableElement.findElements(By.tagName("th"));
		for (WebElement header : headers) {
			if (new WebEssentials(driver).getTidyString(header.getAttribute("innerText"), charactersTobeRemoved).toString().equalsIgnoreCase(textlabel)) {
				header.findElement(By.cssSelector("input")).sendKeys(inputtext);
				header.findElement(By.cssSelector("input")).sendKeys(Keys.ENTER);
			}
		}
		waitForNGToLoad();
		return new NGHelper(driver);
	}

	/**
	 * Method to get List of table header Elements
	 * 
	 * @param uniqueTableElement
	 *        Which should be a WebElement Created using @FindBy annotation
	 * @return List of table header Strings
	 * @throws Exception
	 */
	@SuppressWarnings("null")
	public List<String> returntableHeaderText(WebElement uniqueTableElement, String... charactersTobeRemoved) throws Exception {
		waitForNGToLoad();
		List<String> headerData = new ArrayList<String>();
		List<WebElement> headers = uniqueTableElement.findElements(By.tagName("th"));
		for (WebElement header : headers) {
			headerData.add(new WebEssentials(driver).getTidyString(header.getAttribute("innerText"), charactersTobeRemoved).toString());
		}
		waitForNGToLoad();
		return headerData;
	}

	
	/**
	 * Method to get data of the specified column index  
	 * 
	 * @param enterUniqueTableElement
	 *        Which should be a WebElement of the table created using @FindBy annotation
	 * @param columnNumber
	 *        Which should an integer of the column
	 * @return List of String 
	 * @throws Exception
	 */
	public List<String> returnAllTableColumnData(WebElement enterUniqueTableElement, int columnNumber, String... charactersTobeRemoved) throws Exception{
		waitForNGToLoad();
		List<String> tableColData = new ArrayList<String>();
		int row_count = enterUniqueTableElement.findElements(By.xpath("//tr")).size();
		if (row_count >= 1) {
			for (int row = 1; row <= row_count; row++) {
				try {
					WebElement rem = enterUniqueTableElement
							.findElement(By.xpath("//tr" + "[" + row + "]" + "/td" + "[" + columnNumber + "]"));
					tableColData.add(new WebEssentials(driver).getTidyString(rem.getAttribute("innerText"), charactersTobeRemoved).toString().toLowerCase().trim());
				} catch (Exception noSuch) {
					
				}
			}
			waitForNGToLoad();
			return tableColData;
		} else {
			waitForNGToLoad();
			return tableColData;
		}
	}
	
	
	/**
	 * Method to get all the table data separated with "|" as delimiter
	 * 
	 * @param enterUniqueTableElement
	 *        Which should be a WebElement created using @FindBy annotation
	 * @return List of table rows and columns with delimiter as "|"
	 * @throws Exception
	 */
	public List<String> returnAllTableData(WebElement enterUniqueTableElement, String... charactersTobeRemoved) throws Exception {
		waitForNGToLoad();
		List<String> tableData = new ArrayList<String>();
		List<WebElement> trows = enterUniqueTableElement.findElements(By.tagName("tr"));
		for (WebElement trow : trows) {
			List<WebElement> tdatas = trow.findElements(By.tagName("td"));
			String getrow = "";
			int count = 0;
			for (WebElement tdata : tdatas) {
				if (count == 0) {
					getrow = new WebEssentials(driver).getTidyString(tdata.getAttribute("innerText"), charactersTobeRemoved).toString() + "|";
					count = count + 1;
				} else {
					getrow = getrow + new WebEssentials(driver).getTidyString(tdata.getAttribute("innerText"), charactersTobeRemoved).toString() + "|";
				}
			}
			tableData.add(getrow);
		}
		waitForNGToLoad();
		return tableData;
	}

	
	public static String readPropFile(String filename, String Key) throws Exception {
		Properties prop = new Properties();
		InputStream input = null;
		String value;
		try {
			input = new FileInputStream(filename);
			prop.load(input);
			value = prop.getProperty(Key).toString();
			return value;
		} catch (IOException ex) {
			ex.printStackTrace();
			return null;
		}

	}
	
	
	/**
	 * Method for selecting combo option
	 * 
	 * @param cmbElement
	 *        Which should be a WebElement created using @FindBy annotation
	 * @param repeater
	 *        Which should a String of ng-repeat attribute value
	 * @param value
	 *        Which should be a string same as the combo option
	 * @return new instance of NGHelper
	 * @throws Exception
	 * @deprecated use selectComboOption(String comboOption) instead
	 */
	@Deprecated
    public NGHelper ngComboSelector(WebElement cmbElement,String repeater,String value) throws Exception {
    	cmbElement.click();
    	sleepWait(1);
		WebElement elem=cmbElement.findElement(By.xpath("//*[@ng-repeat="+"'"+repeater+"'"+" and "+"@value="+"'"+ value +"'"+"]"));
		WebDriverWait wait=new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(elem)));
		jScriptScrollAndClick(elem);
		return new NGHelper(driver);
    }
    
	/**
	 * Method for selecting combo option
	 * 
	 * @param cmbElement
	 *        Which should be a WebElement created using @FindBy annotation
	 * @param repeater
	 *        Which should a String of ng-repeat attribute value
	 * @param option
	 *        Which should be a string same as the combo option
	 * @return
	 * @throws Exception
	 * @deprecated use selectComboOption(String comboOption) instead
	 */
	@Deprecated
    public NGHelper ngComboSelectorByText(WebElement cmbElement,String repeater,String option) throws Exception {
    	cmbElement.click();
    	sleepWait(1);
		WebElement elem=cmbElement.findElement(By.xpath("//*[@ng-repeat="+"'"+repeater+"'"+" and "+"text()="+"'"+ option +"'"+"]"));
		WebDriverWait wait=new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(elem)));
		jScriptScrollAndClick(elem);
		return new NGHelper(driver);
    }
    
    
    /**
     * Method to move to the specified WebElement and perform click
     * 
     * @param elem
     *        Which should be a WebElement created using @FindBy annotation
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper moveToElementAndClick(WebElement elem) throws Exception{
    	waitForNGToLoad();
    	Actions acc=new Actions(driver);
    	acc.moveToElement(elem).click().build();
    	acc.perform();
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
    
    /**
     * Method to move to specified locator and perform click
     * 
     * @param byelem
     *        Which should be a Locator e.g. By.xpath("//tr//td"), By.cssSelector("tr&#62;td") etc.
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper moveToElementAndClick(By byelem) throws Exception {
    	waitForNGToLoad();
    	Actions acc=new Actions(driver);
    	WebElement elem=findTheElement(byelem);
    	acc.moveToElement(elem).click().build();
    	acc.perform();
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
   
    /**
     * Method to Send Keys as s string
     * 
     * @param textString
     *        Which should be a String 
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper sendTextKeys(String textString) throws Exception{
    	waitForNGToLoad();
    	Actions acc=new Actions(driver);
    	acc.sendKeys(textString).build().perform();
    	waitForNGToLoad();
		return new NGHelper(driver);
    }
    
    
    /**
     * Method to Select combo option 
     * 
     * @param comboElement
     *        Which should be a locator e.g. By.xpath("//tr//td"), By.cssSelector("tr&#62;td") etc.
     * @param option
     *        Which should be a String
     * @return new instance of NGHelper
     * @throws Exception
     * @deprecated use click and SelectComboOption methods.
     */
    @Deprecated
    public NGHelper selectOptionsUsingKeys(By comboElement, String option) throws Exception {
    	waitForNGToLoad();
		findTheElement(comboElement).click();
		sleepWait(0.75);
		sendTextKeys(option);
		sendBoardKeys(Keys.ENTER);
		sendBoardKeys(Keys.ESCAPE);
		sendBoardKeys(Keys.ESCAPE);
		sleepWait(0.25);
		waitForNGToLoad();
		return new NGHelper(driver);
	} 

    /**
     * Method to Send Keys like ENTER, ESCAPE, TAB, SPACE etc.
     * 
     * @param key
     *        Which should be a Key Object e.g. Keys.ENTER, Keys.ESCAPE, Keys.SPACE etc.
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper sendBoardKeys(Keys key) throws Exception{
    	waitForNGToLoad();
    	Actions acc=new Actions(driver);
    	acc.sendKeys(key).build().perform();
    	waitForNGToLoad();
		return new NGHelper(driver);
    }
    
    /**
     * Method to get the WebElement from a specified locator
     * 
     * @param byElem
     *        Which should be a locator e.g. By.xpath("//input[@name='NAME']"), By.class("new"), By.Tagname("i") etc.
     * @return WebElement of the specified locator
     * @throws Exception
     */
    public WebElement findTheElement(By byElem) throws Exception{
    	waitForNGToLoad();
    	WebElement elem=driver.findElement(byElem);
    	waitForNGToLoad();
    	return elem;
    }
    
    
    
    /**
     * Method to click a WebElement matching the specified locator
     * 
     * @param byElem
     *        Which should be a locator e.g. By.xpath("//input[@name='NAME']"), By.class("new"), By.Tagname("i") etc.
     * @return new instance on NGHelper
     * @throws Exception
     */
    public NGHelper clickBy(By byElem) throws Exception {
    	waitForNGToLoad();
    	if(((RemoteWebDriver)driver).getCapabilities().getBrowserName().equalsIgnoreCase("safari")) {
    		jsClick(findTheElement(byElem));
        	waitForNGToLoad();
        	return new NGHelper(driver);
    	}
    	findTheElement(byElem).click();
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
    /**
     * Method to Click a Drop Down box matching the specified locator 
     * 
     * @param byElem
     *        Which should be a locator e.g. By.xpath("//input[@name='NAME']"), By.class("new"), By.Tagname("i") etc. 
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper clickComboBy(By byElem) throws Exception {
    	waitForNGToLoad();
    	jsClick(findTheElement(byElem));
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }

    
    /**
     * Method to click and Send keys to a specified WebElement 
     * 
     * @param elem
     *        Which should be a WebElement created using @FindBy annotation 
     * @param string
     *        Which should be a String 
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper clickAndSendkeys(WebElement elem,String string) throws Exception {
    	waitForNGToLoad();
    	jsClick(elem);
    	sleepWait(0.5);
    	elem.sendKeys(string);
    	waitForNGToLoad();
		return new NGHelper(driver);
    }
    
    
    /**
     * Method to perform click and Send keys to the specified locator
     * 
     * @param byElem
     *        Which should be a Locator e.g. By.xpath("//label[@aria-label='Product code']/../input"),
     *        By.cssSelector("label[value='New value']&#62;input") etc
     * @param string 
     *        Which should be a String to send to the specified locator element
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper clickAndSendkeys(By byElem,String string) throws Exception {
    	waitForNGToLoad();
    	jsClick(findTheElement(byElem));
    	sleepWait(0.5);
    	findTheElement(byElem).sendKeys(string);
    	waitForNGToLoad();
		return new NGHelper(driver);
    }
    
    
    /**
     * Method to retrieve innerHTML of the specified WebElement 
     * (Note: To be used only if the getAttribute("value") is not working)
     * 
     * @param elem
     *        Which should be a WebElement Created using @FindBy annotation
     * @return value in the form of string for the specified WebElement
     * @throws Exception
     */
    public String retrieveValueJS(WebElement elem) throws Exception {
    	waitForNGToLoad();
    	JavascriptExecutor js=(JavascriptExecutor)driver;
    	waitForNGToLoad();
		return js.executeScript("return arguments[0].value", elem).toString();
    }
    
    
    
    /**
     * Method to perform mouse hover on specified WebElement
     * 
     * @param elem
     *        Which should be a WebElement created using @FindBy annotation
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper mouseHover(WebElement elem) throws Exception {
    	waitForNGToLoad();
    	Actions acc=new Actions(driver);
    	acc.moveToElement(elem).build().perform();
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
    
    
    /**
     * Method to scroll to the specified WebElement
     * 
     * @param elem
     *        Which should be a WebElement created using @FindBy annotation
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper jScriptScroll(WebElement elem) throws Exception {
    	waitForNGToLoad();
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elem);
		waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
    /**
	 * Method to check whether the specified WebElement is Visible
	 * 
	 * @param element
	 *        Which should be a WebElement created using @Findby annotation
	 * @return Boolean value true/false
	 */
	public Boolean checkVisibility(WebElement element) {
    	boolean visible=false;
    	try {
    	   
    	   if (element.isDisplayed()==true) {
    		   visible=true;
    	   }
    	}
    	catch(NoSuchElementException noexcep) {
    			visible=false;
    	}
    	return visible;
    }
	
	/**
	 * Method to check whether the specified WebElement is Selected
	 * 
	 * @param element
	 *        Which should be a WebElement created using @Findby annotation
	 * @return Boolean value true/false
	 */
	public Boolean checkSelected(WebElement element) {
    	boolean selected=false;
    	try {
    	   
    	   if (element.isSelected()==true) {
    		   selected=true;
    	   }
    	}
    	catch(NoSuchElementException noexcep) {
    		   selected=false;
    	}
    	return selected;
    }
	
	
	/**
	 * Method to check whether the specified WebElement is Enabled
	 * 
	 * @param element
	 *        Which should be a WebElement created using @Findby annotation
	 * @return Boolean value true/false
	 */
	public Boolean checkEnabled(WebElement element) {
		boolean selected=false;
    	try {
    	   
    	   if (element.isEnabled()==true) {
    		   selected=true;
    	   }
    	}
    	catch(NoSuchElementException noexcep) {
    		   selected=false;
    	}
    	return selected;
    }
	
	/**
	 * Method to select drop down list option with specified option 
	 * 
	 * @param comboOption
	 *        Which should be a String
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper selectComboOption(String comboOption) throws Exception {
		waitForNGToLoad();
		jsClick(findTheElement(By.xpath("(//div[normalize-space()="+"'"+comboOption+"'" + "])"
				+ "[count(//div[normalize-space()="+"'"+comboOption+"'" + "])]")));
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	/**
	 * Method to get the time taken by application to load, visibility of an Element,
	 * Dismissal of Progress bar, Enabling of an Element.
	 * 
	 * @return time as long
	 */
	public long getTotalAppTime() {
		return ExecutionTimer.returnTime();
    }
	
	/**
	 * Method to wait till the specified WebElement is selected
	 * 
	 * @param elem 
	 *        Which should be a WebElement created using @FindBy annotation
	 * @param timeval
	 *        Which should be an integer value
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitTillElementIsSelected(WebElement elem, int timeval) throws Exception{
		waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.elementToBeSelected(elem)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	
	
	/**
	 * Method to wait till the WebElement matching the specified locator is visible 
	 * 
	 * @param byElem
	 *        Which should be a locator e.g. By.xpath("//input[@name='NAME']"), By.class("new"), By.Tagname("i") etc.
	 * @param timeval
	 *        Which should be an integer
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitTillElementIsVisible(By byElem, int timeval) throws Exception {
		waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOfElementLocated(byElem)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	
	/**
	 * Method to wait till the WebElement matching the specified locator is invisible 
	 * 
	 * @param byElem
	 *        Which should be a locator e.g. By.xpath("//input[@name='NAME']"), By.class("new"), By.Tagname("i") etc.
	 * @param timeval
	 *        Which should be an integer
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitTillElementIsInvisible(By byElem, int timeval) throws Exception{
		waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.invisibilityOfElementLocated(byElem)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	
	/**
	 * Method to wait till the WebElement matching the specified locator is clickable 
	 * 
	 * @param byElem
	 *        Which should be a locator e.g. By.xpath("//input[@name='NAME']"), By.class("new"), By.Tagname("i") etc.
	 * @param timeval
	 *        Which should be an integer
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper waitTillElementIsClickable(By byElem, int timeval) throws Exception{
		waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.elementToBeClickable(byElem)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	
	/**
	 * Method to wait till the WebElement matching the specified locator is selected 
	 * 
	 * @param byElem
	 *        Which should be a locator e.g. By.xpath("//input[@name='NAME']"), By.class("new"), By.Tagname("i") etc.
	 * @param timeval
	 *        Which should be an integer
	 * @return new instance of NGHelper
	 * @throws Exception Exception
	 */
	public NGHelper waitTillElementIsSelected(By byElem, int timeval) throws Exception{
		waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.elementToBeSelected(byElem)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	/**
	 * Method to select the combo option using visible text (Used for non angular combo with select tag)
	 * 
	 * @param comboElement
	 *        Which should be a WebElement created using @Findby annotation
	 * @param visibleText
	 *        Which should be a String.
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper selectComboByText(WebElement comboElement,String visibleText) throws Exception {
		waitForNGToLoad();
		Select select=new Select(comboElement);
		select.selectByVisibleText(visibleText);
		waitForNGToLoad();
		return new NGHelper(driver);
	}
	
	/**
	 * Method to select the combo option using value (Used for non angular combo with select tag)
	 * 
	 * @param comboElement
	 *        Which should be a WebElement created using @Findby annotation
	 *
	 *
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
	public NGHelper selectComboByValue(WebElement comboElement,String value) throws Exception {
		waitForNGToLoad();
		Select select=new Select(comboElement);
		select.selectByValue(value);
		waitForNGToLoad();
		return new NGHelper(driver);
	} 
	
	/**
	 * Method to select the combo option using Index of the Option (Used for non angular combo with select tag)
	 * 
	 * @param comboElement
	 *        Which should be a WebElement created using @Findby annotation
	 * @param
	 *
	 * @return new instance of NGHelper
	 * @throws Exception
	 */
    public NGHelper selectComboByIndex(WebElement comboElement,Integer index) throws Exception {
		waitForNGToLoad();
		Select select=new Select(comboElement);
		select.selectByIndex(index);
		waitForNGToLoad();
		return new NGHelper(driver);
	} 
	
    /**
     * Method to Wait till the Alert is displayed
     * 
     * @param timeval
     *        Which should be an Integer
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper waitTillAlertIsDisplayed(Integer timeval) throws Exception {
    	waitForNGToLoad();
    	WebDriverWait wait=new WebDriverWait(driver, timeval);
    	wait.until(ExpectedConditions.or(ExpectedConditions.alertIsPresent()));
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
    
    /**
     * Method to accept the alert pop up
     * 
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper acceptAlert() throws Exception {
    	waitForNGToLoad();
    	Alert alert=driver.switchTo().alert();
    	alert.accept();
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
    /**
     * Method to dismiss the alert pop up
     * 
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper dismissAlert() throws Exception {
    	waitForNGToLoad();
    	Alert alert=driver.switchTo().alert();
    	alert.dismiss();
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
    
    /**
     * Method to move an element to specified co-ordinates
     * 
     * @param element 
     *        Which should be a WebElement
     * @param xcoordinate 
     *        Which should be an integer
     * @param Ycoordinate 
     *        Which should be an integer
     * @return new instance of NGHelper
     * @throws Exception
     */
    public NGHelper moveElementToOrdinates(WebElement element,Integer xcoordinate,Integer Ycoordinate) throws Exception {
    	waitForNGToLoad();
    	Point point=element.getLocation();
    	Integer xcord=point.getX();
    	Integer ycord=point.getY();
    	Actions actions=new Actions(driver);
    	actions.clickAndHold().moveByOffset(xcord+xcoordinate, ycord+Ycoordinate).release().build().perform();
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
    /**
     * Method to Execute JQuery which returns a String
     * 
     * @param jqueryScript 
     *        Which should be a String
     * @return String which is obtained after executing jqueryScript
     * @throws Exception
     */
    public String returnStringJQuery(String jqueryScript) throws Exception{
    	JavascriptExecutor javascriptExecutor=(JavascriptExecutor)driver;
    	return (String)javascriptExecutor.executeScript(jqueryScript);
    }
    
   
    /**
     * Method to Execute JQuery which returns a WebElement
     * 
     * @param jqueryScript 
     *        Which should be a String
     * @return WebElement which is obtained after executing jqueryScript
     * @throws Exception
     */
    public WebElement returnWebElementUsingJQuery(String jqueryScript) throws Exception{
    	return (WebElement)((JavascriptExecutor)driver).executeScript(jqueryScript);
    }
    
    
    /**
     * Method to Execute JQuery which returns a List of WebElements
     * 
     * @param jqueryScript 
     *        Which should be a String
     * @return List of WebElements matching the jqueryScript
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
	public List<WebElement> returnWebElementsListUsingJQuery(String jqueryScript) throws Exception{
    	return (List<WebElement>)((JavascriptExecutor)driver).executeScript(jqueryScript);
    }
    
 
    /**
     * Method to Execute JQuery which returns an Object
     * 
     * @param jqueryScript 
     *        Which should be a String
     * @return Object which is matching the jqueryScript
     * @throws Exception
     */
    public Object returnObjectJQuery(String jqueryScript) throws Exception {
    	return (Object)((JavascriptExecutor)driver).executeScript(jqueryScript);
    }      
    
    
    
    /**
     * Method to wait till the Locator has the Specified innerText
     * 
     * @param byElem 
              Which should be a locator e.g. By.xpath("//input[@name='NAME']"), By.class("new"), By.Tagname("i") etc.
     * @param innerText
     *        Which should be a String.
     * @param timeval
     * @return
     * @throws Exception
     */
    public NGHelper waitTillTextIsVisible(By byElem,String innerText,int timeval) throws Exception {
    	waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.textToBePresentInElementLocated(byElem, innerText)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
    }
    
    
    /**
     * Method to wait till the Locator has the Specified innerText
     * 
     * @param byElem 
              Which should be a locator e.g. By.xpath("//input[@name='NAME']"), By.class("new"), By.Tagname("i") etc.
     * @param innerText
     *        Which should be a String.
     * @param timeval
     *        which should be an Integer
     * @return new instance of NGHelper;
     * @throws Exception
     */
    public NGHelper waitTillTextIsInvisible(By byElem,String innerText,int timeval) throws Exception {
    	waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.invisibilityOfElementWithText(byElem, innerText)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
    }
    
    
    /**
     * Method to wait till the WebElement has the Specified innerText
     * 
     * @param elem 
              which should be a WebElement created using @Findby annotation
     * @param innerText
     *        Which should be a String.
     * @param timeval
     *        which should be an Integer
     * @return new instance of NGHelper;
     * @throws Exception
     */ 
    public NGHelper waitTillTextIsVisible(WebElement elem,String innerText,int timeval) throws Exception {
    	waitForNGToLoad();
		ExecutionTimer.startTimer();
		WebDriverWait wait = new WebDriverWait(driver, timeval);
		wait.until(ExpectedConditions.or(ExpectedConditions.textToBePresentInElement(elem, innerText)));
		ExecutionTimer.endTimer();
		waitForNGToLoad();
		return new NGHelper(driver);
    }
    
       
    /**
     * Method to get the title of the browser window
     * 
     * @return Title of the current webpage
     * @throws Exception
     */
    public String getTitle() throws Exception {
    	waitForNGToLoad();
    	return driver.getTitle();
    }
    
    /**
     * Method to get the Current URL
     * 
     * @return Current URL of the WebPage
     * @throws Exception
     */
    public String getCurrentURL() throws Exception {
    	waitForNGToLoad();
		return driver.getCurrentUrl();
    }
    
    /**
     * Method to get all the window handles of the browser instances
     * 
     * @return All the window handle in the form of Set of String
     * @throws Exception 
     */
    public Set<String> getAllWindowHandles() throws Exception{
		return driver.getWindowHandles();
    }
    
    /**
     * Method to switch to the specified window handle
     * 
     * @param windowHandle
     *        Which should be a String
     * @return New instance of NgHelper
     * @throws Exception
     */
    public NGHelper switchToWindow(String windowHandle) {
    	driver.switchTo().window(windowHandle);
		return new NGHelper(driver);
    }
    
    
    /**
     * Method to get List of String from the List of Webelements
     * 
     * @param webelems
     *        which should be a list of WebElement
     * @return List of InnerText as Strings List
     */
    public List<String> returnStringFromWebElements(List<WebElement> webelems, String... charactersTobeRemoved){
    	List<String> str=webelems.stream().map(e->new WebEssentials(driver).getTidyString(e.getAttribute("innerText"), charactersTobeRemoved)).collect(Collectors.toList());
    	return str;
    }
    

    /**
     * @param element
     * @return
     * @throws Exception
     */
    public NGHelper submit(WebElement element) throws Exception {
    	waitForNGToLoad();
    	WebElement elem=element;
    	elem.submit();
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
    /**
     * @param byElem
     * @return
     * @throws Exception
     */
    public NGHelper submit(By byElem) throws Exception {
    	waitForNGToLoad();
    	WebElement elem=findTheElement(byElem);
    	elem.submit();
    	waitForNGToLoad();
    	return new NGHelper(driver);
    }
    
}