package com.screen.magic.neo.common.apis;

public class URLGenerator {

    public String REST_ENDPOINT = "/services/data";
    public String API_VERSION = "/v45.0";
    public String createContactURL="/sobjects/Contact/";
    public String instanceURL= null;
    public String queryParamURL = "/query/";
    public String appConfigURL = "/services/apexrest/smagicinteract/AppConfiguration/doPost";

    public URLGenerator(String instanceURL){
        this.instanceURL = instanceURL;
        String baseURL = instanceURL + this.REST_ENDPOINT + this.API_VERSION;
        this.queryParamURL = baseURL + this.queryParamURL;
        this.createContactURL= baseURL + this.createContactURL;
    }

    public URLGenerator(String instanceURL, boolean isCommonEndPoint) {
        this.instanceURL = instanceURL;
        this.appConfigURL = instanceURL + appConfigURL;
    }
}
