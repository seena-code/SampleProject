package com.screen.magic.neo.common.apis.utils;


import com.google.gson.JsonArray;
import com.jayway.restassured.response.Response;

import java.util.Map;
import java.util.Objects;

public class RestValidation {

    public int getStatusCode(Response response){
        return response.getStatusCode();
    }

    public void getJsonArray(Response response){
        JsonArray jsonArray = response.getBody().as(JsonArray.class);
    }

    public boolean exists(Map<String, String> map, String key, String value)
    {
        return map!=null && map.get(key)!=null && Objects.equals(map.get(key),value);
    }


}