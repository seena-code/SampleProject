package com.screen.magic.neo.common.apis;

import com.screen.magic.neo.common.customException.CustomException;

import com.jayway.restassured.response.Response;
import com.screen.magic.neo.common.apis.utils.SFDCRestUtils;
import com.screen.magic.neo.common.customException.ApplicationException;

import java.util.HashMap;
import java.util.Map;

public class SFDCHelper {
    public URLGenerator urlGenerator;
    SFDCRestUtils sfdcRestUtils;
    GeneralHelper generalHelper;

    public SFDCHelper(String baseURL, SFDCRestUtils restUtils ) {
        urlGenerator = new URLGenerator(baseURL);
        sfdcRestUtils = restUtils;
        generalHelper = new GeneralHelper();
    }

    public SFDCHelper(String baseURL, SFDCRestUtils restUtils , boolean isCommonEndPoint) {
        urlGenerator = new URLGenerator(baseURL, isCommonEndPoint);
        sfdcRestUtils = restUtils;
        generalHelper = new GeneralHelper();
    }

    public Response changeCustomSettings(Map<String, String> data) throws Exception {
        try {
            Map<String,Object> payload = new HashMap<String, Object>();
            payload.put("requestType","editProtectedCustomSettings");
            payload.put("data",data);
            Response response = this.sfdcRestUtils.postWithoutAppUrl(this.urlGenerator.appConfigURL, payload);
            if (response.getStatusCode() != 200) {
                throw new ApplicationException("Failure while changing the custom settings using the API :" + this.urlGenerator.appConfigURL + ". The response code was:" + response.getStatusCode() + "and the response body received is: " + response.getBody().asString());
            }
            return response;
        } catch (Exception e) {
            throw new CustomException(e);
        }
    }
}
