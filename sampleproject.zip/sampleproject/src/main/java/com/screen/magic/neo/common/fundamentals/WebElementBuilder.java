package com.screen.magic.neo.common.fundamentals;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class WebElementBuilder {

	private WebElement webelement;
	private List<WebElement> webelements;
	private WebDriver driver;
	
	
	
	/**
	 * @param webelement
	 * @param driver
	 */
	public WebElementBuilder(WebElement webelement, WebDriver driver) {
		this.webelement = webelement;
		this.driver=driver;
	}
	
	/**
	 * @param driver
	 */
	public WebElementBuilder(WebDriver driver) {
		this.driver = driver;
	}
	
	/**
	 * @param webelement
	 */
	public WebElementBuilder(WebElement webelement) {
		this.webelement = webelement;
	}
	
	/**
	 * @param webelements
	 * @param driver
	 */
	public WebElementBuilder(List<WebElement> webelements, WebDriver driver) {
		this.webelements = webelements;
		this.driver=driver;
	}
	
	/**
	 * @return
	 */
	public WebElement getWebElement() {
		return webelement;
	}
	
	/**
	 * @return
	 */
	public List<WebElement> getWebElements() {
		return webelements;
	}
	
	/**
	 * @param locator
	 * @return
	 */
	public WebElementBuilder getElementUnderWebElement(By locator) {
		WebElement elem=webelement.findElement(locator);
		return new WebElementBuilder(elem, driver);
	}
	
	/**
	 * @param locator
	 * @return
	 */
	public WebElementBuilder getAllElementsUnderWebElement(By locator) {
		List<WebElement> webElements=webelement.findElements(locator);
		return new WebElementBuilder(webElements,driver);	
	}
		
	/**
	 * @param csspath
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public WebElementBuilder getAllElementsWithCSS(String csspath) throws Exception {
		String script="return document.querySelectorAll("+'"'+csspath+'"'+");";
		return new WebElementBuilder((List<WebElement>)((JavascriptExecutor)driver).executeScript(script),driver);
	}
	
	/**
	 * @param webElems
	 * @param innerText
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getElementWithText(List<WebElement> webElems,String innerText, String... charactersTobeRemoved) throws Exception {
		WebElement el=webElems.stream()
				              .filter(elem->new WebEssentials(driver).getTidyString(elem.getAttribute("innerText"),charactersTobeRemoved).trim().equals(innerText))
				              .findFirst()
				              .orElse(null);
		return new WebElementBuilder(el,driver);
	} 
	
	/**
	 * @param webElems
	 * @param innerText
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getElementContainingText(List<WebElement> webElems,String innerText, String... charactersTobeRemoved) throws Exception{
		WebElement el=webElems.stream()
							  .filter(elem->new WebEssentials(driver).getTidyString(elem.getAttribute("innerText"), charactersTobeRemoved).trim().contains(innerText))
				              .findFirst()
				              .orElse(null);
		return new WebElementBuilder(el,driver);
	}
	
	/**
	 * @param webElems
	 * @param value
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getElementWithValue(List<WebElement> webElems,String value, String... charactersTobeRemoved) throws Exception{
		WebElement el=webElems.stream()
				              .filter(elem->new WebEssentials(driver).getTidyString(((JavascriptExecutor)driver).executeScript("return arguments[0].value", elem).toString(),
				            		  charactersTobeRemoved)
				              .equals(value))
				              .findFirst()
				              .orElse(null);
		return new WebElementBuilder(el,driver);
	}
	
	/**
	 * @param csspath
	 * @param innerText
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getElementWithCSSText(String csspath,String innerText, String... charactersTobeRemoved) throws Exception{
		WebElement el=getAllElementsWithCSS(csspath).getWebElements()
				                                    .stream()
				                                    .filter(elem->new WebEssentials(driver).getTidyString(elem.getAttribute("innerText"),
				                                    		charactersTobeRemoved).trim().equals(innerText))
				                                    .findFirst()
				                                    .orElse(null);
		return new WebElementBuilder(el,driver);
	}
	
	/**
	 * @param csspath
	 * @param innerText
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getElementContainingCSSText(String csspath,String innerText, String... charactersTobeRemoved) throws Exception {
		WebElement el=getAllElementsWithCSS(csspath).getWebElements()
				                                    .stream()
				                                    .filter(elem->new WebEssentials(driver).getTidyString(elem.getAttribute("innerText"),
				                                    		charactersTobeRemoved).trim().contains(innerText))
				                                    .findFirst()
				                                    .orElse(null);
		return new WebElementBuilder(el,driver);
	}
	
	/**
	 * @param csspath
	 * @param innerText
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getElementsWithCSSText(String csspath,String innerText, String... charactersTobeRemoved) throws Exception {
		List<WebElement> el=getAllElementsWithCSS(csspath).getWebElements()
														  .stream()
														  .filter(elem->new WebEssentials(driver).getTidyString(elem.getAttribute("innerText"),
																  charactersTobeRemoved).trim().equals(innerText))
														  .collect(Collectors.toList());             
		return new WebElementBuilder(el,driver);
	}
		
	/**
	 * @param csspath
	 * @param innerText
	 * @param charactersTobeRemoved
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getElementsContainingCSSText(String csspath,String innerText, String... charactersTobeRemoved) throws Exception {
		List<WebElement> el=getAllElementsWithCSS(csspath).getWebElements()
														  .stream()
														  .filter(elem->new WebEssentials(driver).getTidyString(elem.getAttribute("innerText"),
																  charactersTobeRemoved).trim().contains(innerText))
				                                          .collect(Collectors.toList());     
		return new WebElementBuilder(el,driver);
	}
	
	/**
	 * @param validCSS
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getParentUsingCSS(String validCSS) throws Exception{
		String queryScript = "return arguments[0].closest("+"\""+ validCSS+"\"" +");";
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript(queryScript, webelement),driver);	
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getNextSiblingElement() throws Exception{
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript("return arguments[0].nextElementSibling;", webelement),driver);	
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getPreviousSiblingElement() throws Exception{
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript("return arguments[0].previousElementSibling;", webelement),driver);	
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getParentElement() throws Exception{
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript("return arguments[0].parentElement;", webelement),driver);	
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public WebElementBuilder getChildren() throws Exception{
		return new WebElementBuilder((List<WebElement>)((JavascriptExecutor)driver).executeScript("return arguments[0].children;", webelement),driver);
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getAncestorElement() throws Exception{
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript("return arguments[0].offsetParent;", webelement),driver);
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getFirstChildElement() throws Exception{
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript("return arguments[0].firstElementChild;", webelement),driver);
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	public WebElementBuilder getLastChildElement() throws Exception{
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript("return arguments[0].lastElementChild;", webelement),driver);
	}
	
	/**
	 * @param tagName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public WebElementBuilder getElementsWithTag(String tagName) {
		String script="return arguments[0].getElementsByTagName('"+tagName+"');";
		return new WebElementBuilder((List<WebElement>)((JavascriptExecutor)driver).executeScript(script, webelement),driver);
	}
	
	//Reverted this method to provide fix for the CPQ team.
	/**
	 * @param cssPath
	 * @return
	 */
	public WebElementBuilder getElementWithCSS(String cssPath) {
		String script="return document.querySelector("+'"'+cssPath+'"'+");";
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript(script),driver);
	} 
	
	//Changed the name for this method
	/**
	 * @param cssPath
	 * @return
	 */
	public WebElementBuilder getElementWithDualCSS(String cssPath) {
		String script=cssPath.contains("[")?"return arguments[0].querySelector(\""+cssPath+"\");":"return arguments[0].querySelector('"+cssPath+"');";
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript(script, webelement),driver);
	} 
	
	/**
	 * @param cssPath
	 * @return
	 */
	@SuppressWarnings("unused")
	private WebElementBuilder getElementWithCSSFix(String cssPath) {
	//Added this as a backup for getElementWithCSS for CLM issue
		String script="return document.querySelector("+'"'+cssPath+'"'+");";
		return new WebElementBuilder((WebElement)((JavascriptExecutor)driver).executeScript(script, webelement),driver);
 	} 
	
	@SuppressWarnings("unchecked")
	public WebElementBuilder getAllElementsUnderWebElementWithCSS(String csspath) {
        String script="return arguments[0].querySelectorAll("+'"'+csspath+'"'+");";
        return new WebElementBuilder((List<WebElement>)((JavascriptExecutor)driver).executeScript(script, webelement),driver);
	}

		
	
}