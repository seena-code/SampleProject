package com.screen.magic.tests;

import com.vimalselvam.cucumber.listener.Reporter;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import org.testng.annotations.AfterClass;

import java.io.File;


@CucumberOptions(features = {


      "./src/main/resources/features/AutoPopulatePhoneAndsenderIDPage.feature",
        "./src/main/resources/features/CharacterLimit.feature"

},
        glue = { "com.screen.magic"},
        plugin = {
                "com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:TEST-OUTPUT/AutomationTestReport.html",
                "json:target/reports/cucumber1.json"
        },
        monochrome = true)

public class TestRunner extends AbstractTestNGCucumberTests {


    @AfterClass(alwaysRun = true)
    public void writeExtentReport() {

        Reporter.loadXMLConfig(new File("src/main/resources/extent-config.xml"));
        //StepDefinition.errorClassified
    }



}


